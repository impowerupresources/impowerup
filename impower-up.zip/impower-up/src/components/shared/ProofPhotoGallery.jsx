import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Camera } from "lucide-react";

export default function ProofPhotoGallery({ logs = [], habits = [] }) {
  const [selected, setSelected] = useState(null);
  const proofLogs = logs.filter((l) => l.proof_photo_url);

  if (proofLogs.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground font-body text-sm">
        No proof photos uploaded yet.
      </div>
    );
  }

  const getHabit = (id) => habits.find((h) => h.id === id);

  return (
    <>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {proofLogs.map((log, i) => {
          const habit = getHabit(log.habit_id);
          return (
            <motion.button
              key={log.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.04 }}
              onClick={() => setSelected(log)}
              className="relative aspect-square rounded-2xl overflow-hidden border border-border group"
            >
              <img src={log.proof_photo_url} alt="Proof" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-2">
                <div>
                  {habit && <p className="text-white text-xs font-body font-semibold">{habit.emoji} {habit.title}</p>}
                  <p className="text-white/70 text-[10px] font-body">{log.completed_date}</p>
                </div>
              </div>
            </motion.button>
          );
        })}
      </div>

      <AnimatePresence>
        {selected && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelected(null)}
            className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.8 }}
              className="relative max-w-sm w-full"
              onClick={(e) => e.stopPropagation()}
            >
              <img src={selected.proof_photo_url} alt="Proof" className="w-full rounded-2xl" />
              <div className="bg-card rounded-2xl p-4 mt-2">
                {getHabit(selected.habit_id) && (
                  <p className="font-display font-semibold">
                    {getHabit(selected.habit_id).emoji} {getHabit(selected.habit_id).title}
                  </p>
                )}
                <p className="text-xs text-muted-foreground font-body">Completed on {selected.completed_date}</p>
                {selected.note && <p className="text-sm text-muted-foreground font-body mt-2">{selected.note}</p>}
              </div>
              <button
                onClick={() => setSelected(null)}
                className="absolute -top-3 -right-3 w-8 h-8 rounded-full bg-card border border-border flex items-center justify-center shadow-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}