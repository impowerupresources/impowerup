import React from "react";
import { Outlet, Link, useLocation, useNavigate } from "react-router-dom";
import { Home, Target, Bell, Share2, Trophy, Sparkles, TrendingUp, CalendarDays, Settings, Users } from "lucide-react";
import { motion } from "framer-motion";
import Header from "@/components/Header";
import AlarmManager from "@/components/reminders/AlarmManager";
import { useNavPosition } from "@/lib/useNavPosition";

const navItems = [
  { path: "/", icon: Home, label: "Home" },
  { path: "/habits", icon: Sparkles, label: "Habits" },
  { path: "/goals", icon: Target, label: "Goals" },
  { path: "/planner", icon: CalendarDays, label: "Planner" },
  { path: "/focus", icon: Users, label: "Focus" },
  { path: "/progress", icon: TrendingUp, label: "Progress" },
  { path: "/reminders", icon: Bell, label: "Alarms" },
  { path: "/sharing", icon: Share2, label: "Share" },
  { path: "/settings", icon: Settings, label: "Settings" },
];

function useTabReset() {
  const location = useLocation();
  const navigate = useNavigate();
  return (item) => (e) => {
    const isOnTab = item.path === "/"
      ? location.pathname === "/"
      : location.pathname.startsWith(item.path);
    if (isOnTab) {
      e.preventDefault();
      if (location.pathname !== item.path) {
        navigate(item.path, { replace: true });
      } else {
        window.scrollTo({ top: 0, behavior: "smooth" });
      }
    }
  };
}

function SideNavItem({ item, active }) {
  const handleTabClick = useTabReset();
  return (
    <Link to={item.path} onClick={handleTabClick(item)} className="relative group">
      <motion.div
        className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-colors ${
          active
            ? "bg-primary text-primary-foreground"
            : "text-muted-foreground hover:bg-muted hover:text-foreground"
        }`}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <item.icon className="w-5 h-5" />
      </motion.div>
      <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 bg-foreground text-background text-xs font-body font-semibold px-2 py-1 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
        {item.label}
      </div>
    </Link>
  );
}

function BarNavItem({ item, active }) {
  const handleTabClick = useTabReset();
  return (
    <Link to={item.path} onClick={handleTabClick(item)} className="flex flex-col items-center gap-0.5 flex-1 min-w-0">
      <motion.div
        className={`w-9 h-9 rounded-2xl flex items-center justify-center transition-colors ${
          active ? "bg-primary text-primary-foreground" : "text-muted-foreground"
        }`}
        whileTap={{ scale: 0.9 }}
      >
        <item.icon className="w-5 h-5" />
      </motion.div>
      <span className={`text-[9px] font-body font-semibold truncate ${active ? "text-primary" : "text-muted-foreground"}`}>
        {item.label}
      </span>
    </Link>
  );
}

export default function Layout() {
  const location = useLocation();
  const { navPosition } = useNavPosition();
  const isActive = (path) => (path === "/" ? location.pathname === "/" : location.pathname.startsWith(path));

  const mainPadding = {
    side: "pb-24 md:pb-6 md:pl-20",
    bottom: "pb-24",
    top: "pt-20",
  }[navPosition];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <AlarmManager />
      {navPosition !== "top" && <Header />}
      <main className={`flex-1 ${mainPadding}`}>
        <Outlet />
      </main>

      {/* Side: desktop sidebar */}
      {navPosition === "side" && (
        <nav className="hidden md:flex fixed left-0 top-0 bottom-0 w-20 bg-card border-r border-border flex-col items-center py-8 gap-2 z-50">
          <div className="mb-6">
            <div className="w-10 h-10 rounded-2xl bg-primary flex items-center justify-center">
              <Trophy className="w-5 h-5 text-primary-foreground" />
            </div>
          </div>
          {navItems.map((item) => (
            <SideNavItem key={item.path} item={item} active={isActive(item.path)} />
          ))}
        </nav>
      )}

      {/* Side (mobile) + Bottom (all screens): bottom bar */}
      {(navPosition === "side" || navPosition === "bottom") && (
        <nav
          className={`${navPosition === "side" ? "md:hidden" : ""} fixed bottom-0 left-0 right-0 bg-card/95 backdrop-blur-xl border-t border-border z-50 px-1 pb-[env(safe-area-inset-bottom)]`}
        >
          <div className="flex items-center justify-around py-2 gap-0.5 overflow-x-auto">
            {navItems.map((item) => (
              <BarNavItem key={item.path} item={item} active={isActive(item.path)} />
            ))}
          </div>
        </nav>
      )}

      {/* Top: all screens */}
      {navPosition === "top" && (
        <nav className="fixed top-0 left-0 right-0 bg-card/95 backdrop-blur-xl border-b border-border z-50 px-1 pt-[env(safe-area-inset-top)]">
          <div className="flex items-center justify-around py-2 gap-0.5 overflow-x-auto">
            {navItems.map((item) => (
              <BarNavItem key={item.path} item={item} active={isActive(item.path)} />
            ))}
          </div>
        </nav>
      )}
    </div>
  );
}