import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { motion } from "framer-motion";
import { X } from "lucide-react";
import AlarmSettings from "@/components/reminders/AlarmSettings";

const EMOJI_CATEGORIES = [
  { label: "Fitness", emojis: ["💪", "🏃", "🤸", "🚴", "🏋️", "🧘", "🤽", "🏊", "🧗", "⛹️", "🤾", "🥊", "🤺", "🧘‍♀️", "🧘‍♂️"] },
  { label: "Health", emojis: ["💧", "🥗", "🥦", "🍎", "🥤", "💤", "🫁", "🧠", "❤️", "🦷", "🧴", "🧼", "🚿", "🩺", "💊", "🥗"] },
  { label: "Mindfulness", emojis: ["🧘", "🙏", "🌿", "🫁", "🕯️", "🔔", "🪷", "☯️", "☮️", "🧠", "😌", "🤍", "✨", "🌌", "🧿"] },
  { label: "Productivity", emojis: ["📝", "✍️", "🎯", "✅", "📋", "📌", "⏰", "🗓️", "📊", "🗂️", "💻", "🖥️", "⌨️", "📈", "✏️", "🖊️", "📒", "🔖"] },
  { label: "Learning", emojis: ["📚", "📖", "🎓", "🧠", "🔬", "🧪", "📐", "📏", "🌍", "🗺️", "💡", "🔍", "🧮", "📓", "✏️", "🎓"] },
  { label: "Creativity", emojis: ["🎨", "🎵", "🎸", "🎹", "🥁", "🎤", "🎧", "🎼", "🖌️", "🖼️", "📸", "🎬", "🎭", "✂️", "🧵", "🪡", "📝"] },
  { label: "Social", emojis: ["💬", "🤝", "👥", "❤️", "🫂", "📞", "📱", "💌", "🤗", "😊", "👋", "🗣️", "💌", "💝", "🫶"] },
  { label: "Self Care", emojis: ["🛁", "🧖", "💆", "🧴", "🪥", "🧼", "🚿", "😴", "🛌", "🧖‍♀️", "🧖‍♂️", "💆‍♀️", "💆‍♂️", "🫖", "☕", "🍵", "🧊", "🪞", "🧘"] },
  { label: "Nature", emojis: ["🌿", "🌱", "🌳", "🌻", "🌞", "🌙", "⭐", "🌈", "🌊", "🏔️", "🏕️", "🚶", "🪴", "🍃", "🌸", "🌺", "🍀", "🦋"] },
  { label: "Food & Drink", emojis: ["🥗", "🍎", "🥦", "🥕", "🥤", "💧", "☕", "🍵", "🫖", "🥘", "🍲", "🥣", "🍌", "🫐", "🍓", "🥑", "🥒", "🫗"] },
  { label: "Misc", emojis: ["⭐", "🌟", "✨", "🔥", "⚡", "💎", "🏆", "🥇", "🎖️", "🎁", "🎈", "🎉", "🦸", "🦸‍♀️", "🦸‍♂️", "🙌", "💯", "🚀", "🪄", "🍀"] },
];
const CATEGORIES = [
  { value: "health", label: "Health" },
  { value: "mindfulness", label: "Mindfulness" },
  { value: "productivity", label: "Productivity" },
  { value: "social", label: "Social" },
  { value: "self_care", label: "Self Care" },
  { value: "learning", label: "Learning" },
  { value: "fitness", label: "Fitness" },
  { value: "other", label: "Other" },
];

export default function HabitForm({ habit, linkedReminder, onSubmit, onCancel }) {
  const [form, setForm] = useState({
    title: habit?.title || "",
    description: habit?.description || "",
    emoji: habit?.emoji || "💪",
    category: habit?.category || "other",
    frequency: habit?.frequency || "daily",
    points_per_completion: habit?.points_per_completion || 10,
    alarm: linkedReminder
      ? {
          enabled: true,
          time: linkedReminder.time || "09:00",
          days: linkedReminder.days || ["Mon", "Tue", "Wed", "Thu", "Fri"],
          alarm_level: linkedReminder.alarm_level || "moderate",
          snooze_allowed: linkedReminder.snooze_allowed ?? false,
          max_snoozes: linkedReminder.max_snoozes || 0,
          message: linkedReminder.message || "",
        }
      : { enabled: false, time: "09:00", days: ["Mon", "Tue", "Wed", "Thu", "Fri"], alarm_level: "moderate", snooze_allowed: false, max_snoozes: 0, message: "" },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.title.trim()) return;
    onSubmit(form);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="bg-card rounded-3xl border border-border p-6 shadow-lg"
    >
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-display font-bold text-lg">{habit ? "Edit Habit" : "New Habit"}</h3>
        <Button variant="ghost" size="icon" onClick={onCancel} className="rounded-xl">
          <X className="w-5 h-5" />
        </Button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <Label className="font-body font-semibold text-sm mb-2 block">Pick an emoji</Label>
          <div className="max-h-52 overflow-y-auto space-y-3 p-1 -m-1">
            {EMOJI_CATEGORIES.map((cat) => (
              <div key={cat.label}>
                <p className="text-xs font-body font-semibold text-muted-foreground mb-1.5">{cat.label}</p>
                <div className="flex flex-wrap gap-1.5">
                  {cat.emojis.map((e, idx) => (
                    <button
                      key={`${e}-${idx}`}
                      type="button"
                      onClick={() => setForm({ ...form, emoji: e })}
                      className={`w-9 h-9 rounded-lg text-lg flex items-center justify-center transition-all ${
                        form.emoji === e ? "bg-primary/10 ring-2 ring-primary scale-110" : "bg-muted hover:bg-muted/80"
                      }`}
                    >
                      {e}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <Label className="font-body font-semibold text-sm">Habit Name</Label>
          <Input
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            placeholder="e.g., Drink 8 glasses of water"
            className="mt-1 rounded-xl"
          />
        </div>

        <div>
          <Label className="font-body font-semibold text-sm">Description (optional)</Label>
          <Textarea
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            placeholder="Why this habit matters to you..."
            className="mt-1 rounded-xl h-20"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="font-body font-semibold text-sm">Category</Label>
            <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
              <SelectTrigger className="mt-1 rounded-xl"><SelectValue /></SelectTrigger>
              <SelectContent>
                {CATEGORIES.map((c) => (
                  <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="font-body font-semibold text-sm">XP per completion</Label>
            <Input
              type="number"
              inputMode="numeric"
              pattern="[0-9]*"
              min={1}
              max={100}
              value={form.points_per_completion}
              onChange={(e) => setForm({ ...form, points_per_completion: parseInt(e.target.value) || 10 })}
              className="mt-1 rounded-xl"
            />
          </div>
        </div>

        <AlarmSettings value={form.alarm} onChange={(alarm) => setForm({ ...form, alarm })} />

        <div className="flex gap-3 pt-2">
          <Button type="button" variant="outline" onClick={onCancel} className="flex-1 rounded-2xl font-body font-semibold">
            Cancel
          </Button>
          <Button type="submit" className="flex-1 rounded-2xl font-body font-semibold">
            {habit ? "Save Changes" : "Create Habit"}
          </Button>
        </div>
      </form>
    </motion.div>
  );
}