import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { ChevronLeft, Trophy } from "lucide-react";
import { motion } from "framer-motion";

const ROOT_ROUTES = ["/", "/habits", "/goals", "/planner", "/progress", "/reminders", "/sharing", "/settings"];

const PAGE_TITLES = {
  "/habits": "Habits",
  "/goals": "Goals",
  "/planner": "Planner",
  "/progress": "Progress",
  "/reminders": "Alarms",
  "/sharing": "Share",
  "/settings": "Settings",
};

export default function Header() {
  const location = useLocation();
  const navigate = useNavigate();
  const isRoot = ROOT_ROUTES.includes(location.pathname);
  const title = PAGE_TITLES[location.pathname];

  return (
    <header className="md:hidden sticky top-0 z-40 bg-card/95 backdrop-blur-xl border-b border-border px-4 py-3 flex items-center gap-3 min-h-[56px]" style={{ paddingTop: "calc(0.75rem + env(safe-area-inset-top))" }}>
      {isRoot ? (
        <motion.div
          key="logo"
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex items-center gap-2"
        >
          <div className="w-8 h-8 rounded-xl bg-primary flex items-center justify-center flex-shrink-0">
            <Trophy className="w-4 h-4 text-primary-foreground" />
          </div>
          <span className="font-display font-bold text-base text-foreground">
            {title ?? "NeuroQuest"}
          </span>
        </motion.div>
      ) : (
        <motion.button
          key="back"
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          onClick={() => navigate(-1)}
          className="flex items-center gap-1 text-primary font-body font-semibold text-sm"
        >
          <ChevronLeft className="w-5 h-5" />
          Back
        </motion.button>
      )}
    </header>
  );
}