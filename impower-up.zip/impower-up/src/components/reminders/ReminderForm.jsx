import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { motion } from "framer-motion";
import { X, Volume, Volume1, Volume2, VolumeX } from "lucide-react";

const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const ALARM_LEVELS = [
  { value: "gentle", label: "Gentle", icon: VolumeX, desc: "Soft chime, easy dismiss" },
  { value: "moderate", label: "Moderate", icon: Volume, desc: "Standard alarm, tap to dismiss" },
  { value: "loud", label: "Loud", icon: Volume1, desc: "Loud alarm, multi-tap dismiss" },
  { value: "persistent", label: "Persistent", icon: Volume2, desc: "Hold button to dismiss, no snooze" },
];

export default function ReminderForm({ reminder, habits, onSubmit, onCancel }) {
  const [form, setForm] = useState({
    title: reminder?.title || "",
    habit_id: reminder?.habit_id || "",
    time: reminder?.time || "09:00",
    days: reminder?.days || ["Mon", "Tue", "Wed", "Thu", "Fri"],
    alarm_level: reminder?.alarm_level || "moderate",
    snooze_allowed: reminder?.snooze_allowed ?? false,
    max_snoozes: reminder?.max_snoozes || 0,
    message: reminder?.message || "",
    is_active: reminder?.is_active ?? true,
  });

  const toggleDay = (day) => {
    setForm({
      ...form,
      days: form.days.includes(day) ? form.days.filter((d) => d !== day) : [...form.days, day],
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.title.trim()) return;
    if (form.alarm_level === "persistent") {
      form.snooze_allowed = false;
      form.max_snoozes = 0;
    }
    onSubmit(form);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="bg-card rounded-3xl border border-border p-6 shadow-lg"
    >
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-display font-bold text-lg">{reminder ? "Edit Reminder" : "New Reminder"}</h3>
        <Button variant="ghost" size="icon" onClick={onCancel} className="rounded-xl">
          <X className="w-5 h-5" />
        </Button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <Label className="font-body font-semibold text-sm">Reminder Title</Label>
          <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="e.g., Time to meditate!" className="mt-1 rounded-xl" />
        </div>

        {habits && habits.length > 0 && (
          <div>
            <Label className="font-body font-semibold text-sm">Link to Habit (optional)</Label>
            <Select value={form.habit_id} onValueChange={(v) => setForm({ ...form, habit_id: v })}>
              <SelectTrigger className="mt-1 rounded-xl"><SelectValue placeholder="Select a habit" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none">No habit linked</SelectItem>
                {habits.map((h) => (
                  <SelectItem key={h.id} value={h.id}>{h.emoji} {h.title}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        <div>
          <Label className="font-body font-semibold text-sm">Time</Label>
          <Input type="time" value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })} className="mt-1 rounded-xl" />
        </div>

        <div>
          <Label className="font-body font-semibold text-sm mb-2 block">Days</Label>
          <div className="flex gap-2">
            {DAYS.map((day) => (
              <button
                key={day}
                type="button"
                onClick={() => toggleDay(day)}
                className={`w-10 h-10 rounded-xl text-xs font-body font-bold transition-all ${
                  form.days.includes(day) ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                }`}
              >
                {day}
              </button>
            ))}
          </div>
        </div>

        <div>
          <Label className="font-body font-semibold text-sm mb-2 block">Alarm Level</Label>
          <div className="grid grid-cols-2 gap-2">
            {ALARM_LEVELS.map((level) => (
              <button
                key={level.value}
                type="button"
                onClick={() => setForm({ ...form, alarm_level: level.value })}
                className={`p-3 rounded-2xl border-2 text-left transition-all ${
                  form.alarm_level === level.value
                    ? "border-primary bg-primary/5"
                    : "border-border hover:border-primary/30"
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <level.icon className={`w-4 h-4 ${form.alarm_level === level.value ? "text-primary" : "text-muted-foreground"}`} />
                  <span className="font-display font-semibold text-sm">{level.label}</span>
                </div>
                <p className="text-xs text-muted-foreground font-body">{level.desc}</p>
              </button>
            ))}
          </div>
        </div>

        {form.alarm_level !== "persistent" && (
          <div className="flex items-center justify-between bg-muted rounded-2xl p-4">
            <div>
              <p className="font-body font-semibold text-sm">Allow Snooze</p>
              <p className="text-xs text-muted-foreground font-body">Let yourself snooze the alarm</p>
            </div>
            <Switch checked={form.snooze_allowed} onCheckedChange={(v) => setForm({ ...form, snooze_allowed: v, max_snoozes: v ? 1 : 0 })} />
          </div>
        )}

        <div>
          <Label className="font-body font-semibold text-sm">Motivational Message</Label>
          <Textarea
            value={form.message}
            onChange={(e) => setForm({ ...form, message: e.target.value })}
            placeholder="You've got this! 💪"
            className="mt-1 rounded-xl h-16"
          />
        </div>

        <div className="flex gap-3 pt-2">
          <Button type="button" variant="outline" onClick={onCancel} className="flex-1 rounded-2xl font-body font-semibold">Cancel</Button>
          <Button type="submit" className="flex-1 rounded-2xl font-body font-semibold">{reminder ? "Save" : "Create Reminder"}</Button>
        </div>
      </form>
    </motion.div>
  );
}