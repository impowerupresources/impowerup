import React, { useState, useEffect, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Bell, BellOff, Volume2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function AlarmModal({ reminder, onDismiss, onSnooze }) {
  const [shakeCount, setShakeCount] = useState(0);
  const [dismissProgress, setDismissProgress] = useState(0);
  const holdTimerRef = useRef(null);
  const isPersistent = reminder?.alarm_level === "persistent";
  const canSnooze = reminder?.snooze_allowed && (reminder?.max_snoozes || 0) > 0;

  // Play alarm sound
  useEffect(() => {
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    let intervalId;

    const playTone = () => {
      const level = reminder?.alarm_level || "moderate";
      // Fog horn: deep frequencies, high volume, long blast
      const baseFreq = { gentle: 200, moderate: 160, loud: 130, persistent: 110 }[level];
      const volume = { gentle: 0.35, moderate: 0.55, loud: 0.75, persistent: 0.95 }[level];
      const duration = { gentle: 0.9, moderate: 1.3, loud: 1.6, persistent: 2.0 }[level];

      // Layered oscillators for a rich, loud fog-horn blast
      const layers = [
        { type: "sawtooth", mult: 1.0, vol: 0.5 },
        { type: "square", mult: 2.0, vol: 0.3 },
        { type: "sine", mult: 0.5, vol: 0.4 }, // sub-bass rumble
      ];

      layers.forEach((layer) => {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);

        osc.type = layer.type;
        const freq = baseFreq * layer.mult;
        osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
        // Slight pitch droop for horn character
        osc.frequency.exponentialRampToValueAtTime(freq * 0.92, audioCtx.currentTime + duration);

        const peakVol = volume * layer.vol;
        gain.gain.setValueAtTime(0, audioCtx.currentTime);
        gain.gain.linearRampToValueAtTime(peakVol, audioCtx.currentTime + 0.08); // quick attack
        gain.gain.setValueAtTime(peakVol, audioCtx.currentTime + duration * 0.7);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);

        osc.start();
        osc.stop(audioCtx.currentTime + duration);
      });
    };

    const speed = { gentle: 2800, moderate: 2200, loud: 1900, persistent: 2300 }[reminder?.alarm_level || "moderate"];
    playTone();
    intervalId = setInterval(playTone, speed);

    return () => {
      clearInterval(intervalId);
      audioCtx.close();
    };
  }, [reminder]);

  const startDismiss = useCallback(() => {
    if (isPersistent) {
      let prog = 0;
      holdTimerRef.current = setInterval(() => {
        prog += 2;
        setDismissProgress(prog);
        if (prog >= 100) {
          clearInterval(holdTimerRef.current);
          onDismiss();
        }
      }, 30);
    }
  }, [isPersistent, onDismiss]);

  const cancelDismiss = useCallback(() => {
    if (holdTimerRef.current) {
      clearInterval(holdTimerRef.current);
      setDismissProgress(0);
    }
  }, []);

  const handleDismissClick = () => {
    if (isPersistent) return; // must hold
    setShakeCount((c) => c + 1);
    if (shakeCount >= 2) {
      onDismiss();
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
      >
        <motion.div
          className="bg-card rounded-3xl p-8 max-w-sm w-full text-center shadow-2xl"
          animate={shakeCount > 0 ? { x: [0, -10, 10, -10, 10, 0] } : {}}
          transition={{ duration: 0.4 }}
        >
          <motion.div
            className="w-20 h-20 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-6"
            animate={{ scale: [1, 1.1, 1] }}
            transition={{ duration: 0.5, repeat: Infinity }}
          >
            <Bell className="w-10 h-10 text-destructive" />
          </motion.div>

          <h2 className="font-display font-bold text-2xl text-foreground mb-2">
            {reminder?.title || "Reminder!"}
          </h2>
          {reminder?.message && (
            <p className="text-muted-foreground font-body mb-6">{reminder.message}</p>
          )}

          <div className="flex items-center justify-center gap-2 mb-6 bg-muted rounded-2xl p-3">
            <Volume2 className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm font-body font-semibold capitalize text-muted-foreground">
              {reminder?.alarm_level || "moderate"} alarm
            </span>
          </div>

          <div className="space-y-3">
            {isPersistent ? (
              <div>
                <Button
                  className="w-full rounded-2xl font-body font-bold h-14 text-base relative overflow-hidden"
                  variant="destructive"
                  onMouseDown={startDismiss}
                  onMouseUp={cancelDismiss}
                  onMouseLeave={cancelDismiss}
                  onTouchStart={startDismiss}
                  onTouchEnd={cancelDismiss}
                >
                  <div
                    className="absolute inset-0 bg-white/20 transition-all"
                    style={{ width: `${dismissProgress}%` }}
                  />
                  <span className="relative z-10">
                    {dismissProgress > 0 ? `Hold... ${Math.round(dismissProgress)}%` : "Hold to Dismiss"}
                  </span>
                </Button>
                <p className="text-xs text-muted-foreground font-body mt-2">Press and hold the button for 1.5 seconds</p>
              </div>
            ) : (
              <Button
                className="w-full rounded-2xl font-body font-bold h-12"
                variant="destructive"
                onClick={handleDismissClick}
              >
                <BellOff className="w-4 h-4 mr-2" />
                {shakeCount === 0 ? "Dismiss" : shakeCount === 1 ? "Tap Again to Dismiss" : "Dismiss"}
              </Button>
            )}

            {canSnooze && (
              <Button variant="outline" className="w-full rounded-2xl font-body" onClick={onSnooze}>
                Snooze (5 min)
              </Button>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}