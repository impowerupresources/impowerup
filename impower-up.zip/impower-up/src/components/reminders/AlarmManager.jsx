import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import AlarmModal from "@/components/reminders/AlarmModal";

export default function AlarmManager() {
  const [activeAlarm, setActiveAlarm] = useState(null);
  const dismissedRef = useRef({});
  const checkIntervalRef = useRef(null);

  const { data: reminders = [] } = useQuery({
    queryKey: ["reminders"],
    queryFn: () => base44.entities.Reminder.list(),
  });

  const { data: dayPlans = [] } = useQuery({
    queryKey: ["day-plans"],
    queryFn: () => base44.entities.DayPlan.list("-date", 400),
  });

  const { data: templates = [] } = useQuery({
    queryKey: ["schedule-templates"],
    queryFn: () => base44.entities.ScheduleTemplate.list(),
  });

  useEffect(() => {
    const checkAlarms = () => {
      if (activeAlarm) return;

      const now = new Date();
      const currentTime = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
      const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
      const currentDay = dayNames[now.getDay()];
      const todayStr = format(now, "yyyy-MM-dd");

      // 1. Check Reminder entities (habits, goals, standalone)
      const reminderTrigger = reminders.find(
        (r) =>
          r.is_active &&
          r.time === currentTime &&
          (r.days || []).includes(currentDay) &&
          dismissedRef.current[`r-${r.id}`] !== todayStr
      );
      if (reminderTrigger) {
        setActiveAlarm(reminderTrigger);
        return;
      }

      // 2. Check planner time blocks for today
      const todayPlan = dayPlans.find((p) => p.date === todayStr);
      if (todayPlan?.template_id) {
        const template = templates.find((t) => t.id === todayPlan.template_id);
        if (template?.time_blocks) {
          const block = template.time_blocks.find(
            (b, i) =>
              b.time === currentTime &&
              dismissedRef.current[`b-${todayStr}-${b.time}-${i}`] !== todayStr
          );
          if (block) {
            setActiveAlarm({
              id: `planner-${block.time}`,
              title: block.label || "Scheduled Task",
              message: `Time for your planned ${block.type}`,
              alarm_level: "moderate",
              snooze_allowed: true,
              max_snoozes: 1,
              is_active: true,
              _dismissKey: `b-${todayStr}-${block.time}`,
            });
          }
        }
      }
    };

    checkAlarms();
    checkIntervalRef.current = setInterval(checkAlarms, 30000);
    return () => clearInterval(checkIntervalRef.current);
  }, [reminders, dayPlans, templates, activeAlarm]);

  if (!activeAlarm) return null;

  const dismissKey = activeAlarm._dismissKey || `r-${activeAlarm.id}`;

  return (
    <AlarmModal
      reminder={activeAlarm}
      onDismiss={() => {
        const todayStr = format(new Date(), "yyyy-MM-dd");
        dismissedRef.current[dismissKey] = todayStr;
        setActiveAlarm(null);
      }}
      onSnooze={() => {
        const snoozed = activeAlarm;
        setActiveAlarm(null);
        setTimeout(() => setActiveAlarm(snoozed), 5 * 60 * 1000);
      }}
    />
  );
}