import React from "react";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { motion, AnimatePresence } from "framer-motion";
import { Bell, Volume, Volume1, Volume2, VolumeX } from "lucide-react";

const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const ALARM_LEVELS = [
  { value: "gentle", label: "Gentle", icon: VolumeX },
  { value: "moderate", label: "Moderate", icon: Volume },
  { value: "loud", label: "Loud", icon: Volume1 },
  { value: "persistent", label: "Persistent", icon: Volume2 },
];

const DEFAULT = {
  enabled: false,
  time: "09:00",
  days: ["Mon", "Tue", "Wed", "Thu", "Fri"],
  alarm_level: "moderate",
  snooze_allowed: false,
  max_snoozes: 0,
  message: "",
};

export default function AlarmSettings({ value, onChange }) {
  const alarm = { ...DEFAULT, ...(value || {}) };
  const update = (patch) => onChange({ ...alarm, ...patch });
  const toggleDay = (day) =>
    update({ days: alarm.days.includes(day) ? alarm.days.filter((d) => d !== day) : [...alarm.days, day] });

  return (
    <div className="bg-muted/50 rounded-2xl p-4 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bell className="w-4 h-4 text-primary" />
          <span className="font-body font-semibold text-sm">Reminder &amp; Alarm</span>
        </div>
        <Switch checked={alarm.enabled} onCheckedChange={(v) => update({ enabled: v })} />
      </div>

      <AnimatePresence>
        {alarm.enabled && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="space-y-4 overflow-hidden"
          >
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs font-body font-semibold">Time</Label>
                <Input
                  type="time"
                  value={alarm.time}
                  onChange={(e) => update({ time: e.target.value })}
                  className="mt-1 rounded-xl"
                />
              </div>
              <div>
                <Label className="text-xs font-body font-semibold">Alarm Level</Label>
                <div className="flex gap-1 mt-1">
                  {ALARM_LEVELS.map((level) => (
                    <button
                      key={level.value}
                      type="button"
                      onClick={() => update({ alarm_level: level.value })}
                      className={`flex-1 h-9 rounded-lg flex items-center justify-center transition-all ${
                        alarm.alarm_level === level.value
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted text-muted-foreground"
                      }`}
                      title={level.label}
                    >
                      <level.icon className="w-3.5 h-3.5" />
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div>
              <Label className="text-xs font-body font-semibold mb-2 block">Days</Label>
              <div className="flex gap-1.5">
                {DAYS.map((day) => (
                  <button
                    key={day}
                    type="button"
                    onClick={() => toggleDay(day)}
                    className={`flex-1 h-9 rounded-lg text-xs font-body font-bold transition-all ${
                      alarm.days.includes(day)
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-muted-foreground"
                    }`}
                  >
                    {day}
                  </button>
                ))}
              </div>
            </div>

            {alarm.alarm_level !== "persistent" && (
              <div className="flex items-center justify-between">
                <span className="text-xs font-body font-semibold">Allow Snooze</span>
                <Switch
                  checked={alarm.snooze_allowed}
                  onCheckedChange={(v) => update({ snooze_allowed: v, max_snoozes: v ? 1 : 0 })}
                />
              </div>
            )}

            <Textarea
              value={alarm.message}
              onChange={(e) => update({ message: e.target.value })}
              placeholder="Motivational message (optional) 💪"
              className="rounded-xl h-14 text-sm"
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}