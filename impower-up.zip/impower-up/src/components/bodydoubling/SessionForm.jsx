import React, { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Loader2, X } from "lucide-react";
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from "@/components/ui/select";

const DURATIONS = [
  { value: 15, label: "15 min" },
  { value: 25, label: "25 min" },
  { value: 50, label: "50 min" },
  { value: 75, label: "75 min" },
];

const ALL_MINUTES = [5, 10, 15, 20, 25, 30, 40, 45, 50, 60, 75, 90, 120];

export default function SessionForm({ onSubmit, onCancel, isSubmitting }) {
  const [intention, setIntention] = useState("");
  const [duration, setDuration] = useState(25);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!intention.trim()) return;
    onSubmit({ intention: intention.trim(), duration_minutes: duration });
  };

  return (
    <motion.form
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      onSubmit={handleSubmit}
      className="bg-card rounded-3xl border border-border p-5 space-y-4"
    >
      <div className="flex items-center justify-between">
        <h2 className="font-display font-bold text-base">New Focus Session</h2>
        <button type="button" onClick={onCancel} className="text-muted-foreground hover:text-foreground">
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="space-y-2">
        <Label htmlFor="intention">What will you work on?</Label>
        <Textarea
          id="intention"
          placeholder="e.g., Finish writing my essay, organize my inbox, study for biology..."
          value={intention}
          onChange={(e) => setIntention(e.target.value)}
          rows={3}
          className="rounded-xl resize-none"
        />
      </div>

      <div className="space-y-2">
        <Label>Session length</Label>
        <div className="grid grid-cols-4 gap-2">
          {DURATIONS.map((d) => (
            <button
              key={d.value}
              type="button"
              onClick={() => setDuration(d.value)}
              className={`py-3 rounded-xl font-body font-semibold text-sm transition-all ${
                duration === d.value
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground hover:bg-muted/80"
              }`}
            >
              {d.label}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground font-body">Or choose:</span>
          <Select value={String(duration)} onValueChange={(v) => setDuration(Number(v))}>
            <SelectTrigger className="w-32 rounded-xl h-9">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {ALL_MINUTES.map((m) => (
                <SelectItem key={m} value={String(m)}>
                  {m} min
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <Button
        type="submit"
        disabled={isSubmitting || !intention.trim()}
        className="w-full rounded-2xl font-body font-semibold"
      >
        {isSubmitting ? (
          <>
            <Loader2 className="w-4 h-4 mr-2 animate-spin" /> Finding your partner...
          </>
        ) : (
          "Start Session"
        )}
      </Button>
    </motion.form>
  );
}