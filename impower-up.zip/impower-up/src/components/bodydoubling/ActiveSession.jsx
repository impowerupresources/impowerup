import React, { useState, useEffect, useMemo } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Loader2, Flag } from "lucide-react";

const MOODS = [
  { value: "great", label: "Great", emoji: "🎉" },
  { value: "good", label: "Good", emoji: "👍" },
  { value: "okay", label: "Okay", emoji: "😐" },
  { value: "struggled", label: "Struggled", emoji: "😅" },
];

function formatTime(seconds) {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export default function ActiveSession({ session, onComplete, onCancel, isCompleting }) {
  const [now, setNow] = useState(Date.now());
  const [ending, setEnding] = useState(false);
  const [completionNote, setCompletionNote] = useState("");
  const [mood, setMood] = useState("good");

  const endTime = useMemo(() => {
    const start = new Date(session.start_time).getTime();
    return start + session.duration_minutes * 60 * 1000;
  }, [session.start_time, session.duration_minutes]);

  const remaining = Math.max(0, Math.floor((endTime - now) / 1000));
  const totalSeconds = session.duration_minutes * 60;
  const progress = totalSeconds > 0 ? ((totalSeconds - remaining) / totalSeconds) * 100 : 0;
  const isTimeUp = remaining === 0;

  useEffect(() => {
    if (ending) return;
    const interval = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(interval);
  }, [ending]);

  useEffect(() => {
    if (isTimeUp && !ending) setEnding(true);
  }, [isTimeUp, ending]);

  if (ending) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-card rounded-3xl border border-border p-6 space-y-5"
      >
        <div className="text-center space-y-2">
          <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto">
            <Flag className="w-8 h-8 text-primary" />
          </div>
          <h2 className="font-display font-bold text-xl">Session Complete!</h2>
          <p className="text-sm text-muted-foreground">
            {session.partner_name} is waiting to hear how it went.
          </p>
        </div>

        <div className="bg-muted/50 rounded-2xl p-4">
          <p className="text-xs text-muted-foreground font-body font-semibold mb-1">Your intention was:</p>
          <p className="text-sm font-body">{session.intention}</p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="completion">How did it go?</Label>
          <Textarea
            id="completion"
            placeholder="What did you accomplish?"
            value={completionNote}
            onChange={(e) => setCompletionNote(e.target.value)}
            rows={3}
            className="rounded-xl resize-none"
          />
        </div>

        <div className="space-y-2">
          <Label>How do you feel?</Label>
          <div className="grid grid-cols-4 gap-2">
            {MOODS.map((m) => (
              <button
                key={m.value}
                type="button"
                onClick={() => setMood(m.value)}
                className={`flex flex-col items-center gap-1 py-3 rounded-xl transition-all ${
                  mood === m.value ? "bg-primary/10 ring-2 ring-primary" : "bg-muted hover:bg-muted/80"
                }`}
              >
                <span className="text-xl">{m.emoji}</span>
                <span className="text-[10px] font-body font-semibold">{m.label}</span>
              </button>
            ))}
          </div>
        </div>

        <Button
          onClick={() => onComplete(completionNote.trim(), mood)}
          disabled={isCompleting || !completionNote.trim()}
          className="w-full rounded-2xl font-body font-semibold"
        >
          {isCompleting ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" /> Getting partner response...
            </>
          ) : (
            "Share with Partner"
          )}
        </Button>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-5"
    >
      <div className="text-center">
        <h1 className="text-2xl md:text-3xl font-display font-bold text-foreground">Focus Session</h1>
        <p className="text-muted-foreground text-sm mt-1">Working with {session.partner_name}</p>
      </div>

      <div className="relative flex items-center justify-center">
        <svg className="w-56 h-56 -rotate-90" viewBox="0 0 200 200">
          <circle cx="100" cy="100" r="90" fill="none" stroke="hsl(var(--muted))" strokeWidth="12" />
          <circle
            cx="100"
            cy="100"
            r="90"
            fill="none"
            stroke="hsl(var(--primary))"
            strokeWidth="12"
            strokeLinecap="round"
            strokeDasharray={2 * Math.PI * 90}
            strokeDashoffset={2 * Math.PI * 90 * (1 - progress / 100)}
            className="transition-all duration-1000 ease-linear"
          />
        </svg>
        <div className="absolute flex flex-col items-center">
          <span className="text-4xl font-display font-bold tabular-nums">{formatTime(remaining)}</span>
          <span className="text-xs text-muted-foreground font-body font-semibold mt-1">
            {isTimeUp ? "Time's up!" : "remaining"}
          </span>
        </div>
      </div>

      <div className="bg-card rounded-2xl border border-border p-4">
        <p className="text-xs text-muted-foreground font-body font-semibold mb-1">Working on</p>
        <p className="text-sm font-body">{session.intention}</p>
      </div>

      <div className="bg-primary/5 rounded-2xl border border-primary/20 p-4 flex gap-3">
        <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
          <span className="font-display font-bold text-primary text-sm">
            {(session.partner_name?.[0] || "?").toUpperCase()}
          </span>
        </div>
        <div>
          <p className="text-xs font-body font-semibold text-primary mb-1">{session.partner_name}</p>
          <p className="text-sm font-body">{session.partner_greeting}</p>
        </div>
      </div>

      <Button variant="outline" onClick={() => setEnding(true)} className="w-full rounded-2xl font-body font-semibold">
        <Flag className="w-4 h-4 mr-2" /> End Session Early
      </Button>
    </motion.div>
  );
}