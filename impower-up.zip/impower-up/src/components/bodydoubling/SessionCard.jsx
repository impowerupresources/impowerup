import React from "react";
import { format } from "date-fns";
import { Clock } from "lucide-react";

const MOOD_EMOJIS = {
  great: "🎉",
  good: "👍",
  okay: "😐",
  struggled: "😅",
};

export default function SessionCard({ session }) {
  return (
    <div className="bg-card rounded-2xl border border-border p-4 space-y-3">
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1">
          <p className="text-xs text-muted-foreground font-body">
            {session.end_time ? format(new Date(session.end_time), "MMM d, h:mm a") : ""}
          </p>
          <p className="font-body font-semibold text-sm mt-0.5">{session.intention}</p>
        </div>
        <div className="flex items-center gap-1 text-xs text-muted-foreground font-body shrink-0">
          <Clock className="w-3 h-3" />
          {session.duration_minutes}m
        </div>
      </div>

      {session.completion_note && (
        <p className="text-sm text-muted-foreground font-body bg-muted/50 rounded-xl p-3">
          {session.completion_note}
        </p>
      )}

      {session.partner_response && (
        <div className="bg-primary/5 rounded-xl p-3 flex gap-2">
          <span className="text-lg shrink-0">{MOOD_EMOJIS[session.mood] || "✨"}</span>
          <div>
            <p className="text-xs font-body font-semibold text-primary mb-0.5">{session.partner_name} says:</p>
            <p className="text-sm font-body">{session.partner_response}</p>
          </div>
        </div>
      )}
    </div>
  );
}