import React from "react";
import { motion } from "framer-motion";
import { Trophy, Flame, Zap, Star } from "lucide-react";

const levelThresholds = [0, 100, 300, 600, 1000, 1500, 2200, 3000, 4000, 5500];
const levelNames = ["Seedling", "Sprout", "Bloom", "Spark", "Blaze", "Star", "Nova", "Legend", "Titan", "Champion"];

export default function PointsBanner({ totalPoints, currentStreak, habitsToday, habitsTotal }) {
  const level = levelThresholds.findIndex((t, i) => {
    const next = levelThresholds[i + 1];
    return next === undefined || totalPoints < next;
  });
  const currentLevelMin = levelThresholds[level] || 0;
  const nextLevelMin = levelThresholds[level + 1] || currentLevelMin + 500;
  const progress = ((totalPoints - currentLevelMin) / (nextLevelMin - currentLevelMin)) * 100;

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary via-primary/90 to-secondary p-6 text-primary-foreground"
    >
      <div className="absolute top-0 right-0 w-40 h-40 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2" />
      <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/2" />

      <div className="relative z-10">
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-sm font-body opacity-80">Level {level + 1} — {levelNames[level]}</p>
            <h2 className="text-3xl font-display font-bold flex items-center gap-2">
              <Zap className="w-7 h-7" />
              {totalPoints} XP
            </h2>
          </div>
          <motion.div
            className="w-16 h-16 rounded-2xl bg-white/15 backdrop-blur-sm flex items-center justify-center"
            animate={{ rotate: [0, 5, -5, 0] }}
            transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
          >
            <Trophy className="w-8 h-8" />
          </motion.div>
        </div>

        <div className="mb-4">
          <div className="flex justify-between text-xs font-body opacity-80 mb-1">
            <span>{totalPoints - currentLevelMin} / {nextLevelMin - currentLevelMin} XP to next level</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <div className="h-3 bg-white/20 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-white/80 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${Math.min(progress, 100)}%` }}
              transition={{ duration: 1, ease: "easeOut" }}
            />
          </div>
        </div>

        <div className="flex gap-4">
          <div className="flex items-center gap-2 bg-white/10 rounded-2xl px-3 py-2">
            <Flame className="w-4 h-4 text-accent" />
            <div>
              <p className="text-xs opacity-70">Streak</p>
              <p className="font-display font-bold text-sm">{currentStreak} days</p>
            </div>
          </div>
          <div className="flex items-center gap-2 bg-white/10 rounded-2xl px-3 py-2">
            <Star className="w-4 h-4 text-accent" />
            <div>
              <p className="text-xs opacity-70">Today</p>
              <p className="font-display font-bold text-sm">{habitsToday}/{habitsTotal}</p>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}