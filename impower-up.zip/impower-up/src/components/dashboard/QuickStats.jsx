import React from "react";
import { motion } from "framer-motion";
import { TrendingUp, Calendar, Target, Award } from "lucide-react";

const stats = [
  { key: "weekly", icon: Calendar, label: "This Week", color: "text-primary bg-primary/10" },
  { key: "goals", icon: Target, label: "Active Goals", color: "text-secondary bg-secondary/10" },
  { key: "best", icon: Award, label: "Best Streak", color: "text-accent bg-accent/10" },
  { key: "trend", icon: TrendingUp, label: "Completion", color: "text-chart-4 bg-chart-4/10" },
];

export default function QuickStats({ weeklyCompletions, activeGoals, bestStreak, completionRate }) {
  const values = {
    weekly: weeklyCompletions,
    goals: activeGoals,
    best: `${bestStreak}d`,
    trend: `${completionRate}%`,
  };

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
      {stats.map((stat, i) => (
        <motion.div
          key={stat.key}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.1 }}
          className="bg-card rounded-2xl border border-border p-4"
        >
          <div className={`w-10 h-10 rounded-xl ${stat.color} flex items-center justify-center mb-3`}>
            <stat.icon className="w-5 h-5" />
          </div>
          <p className="text-2xl font-display font-bold text-foreground">{values[stat.key]}</p>
          <p className="text-xs text-muted-foreground font-body">{stat.label}</p>
        </motion.div>
      ))}
    </div>
  );
}