import React, { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Check, Sparkles, Camera, Loader2 } from "lucide-react";
import { celebrateStreak } from "@/lib/celebrate";

export default function HabitCheckCard({ habit, isCompleted, proofPhotoUrl, onToggle, onAddProof }) {
  const [justCompleted, setJustCompleted] = useState(false);
  const [milestoneHit, setMilestoneHit] = useState(null);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);

  const fireCelebration = () => {
    const newStreak = (habit.current_streak || 0) + 1;
    const isMilestone = celebrateStreak(newStreak);
    setJustCompleted(true);
    setMilestoneHit(isMilestone ? newStreak : null);
    setTimeout(() => { setJustCompleted(false); setMilestoneHit(null); }, 2000);
  };

  const handleToggle = () => {
    if (!isCompleted) fireCelebration();
    onToggle();
  };

  const handleCameraClick = (e) => {
    e.stopPropagation();
    fileInputRef.current?.click();
  };

  const handleFileChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const wasNew = await onAddProof(file);
      if (wasNew) fireCelebration();
    } finally {
      setUploading(false);
      e.target.value = "";
    }
  };

  return (
    <motion.div
      className={`relative w-full flex items-center gap-2 p-4 rounded-2xl border-2 transition-all ${
        isCompleted
          ? "bg-primary/5 border-primary/30 shadow-[0_0_20px_-5px_hsl(var(--primary)/0.3)]"
          : "bg-card border-border hover:border-primary/40 hover:shadow-md"
      }`}
      whileHover={{ scale: 1.01 }}
      whileTap={{ scale: 0.98 }}
      animate={justCompleted ? { scale: [1, 1.03, 1] } : {}}
      transition={justCompleted ? { duration: 0.4 } : {}}
      layout
    >
      <button onClick={handleToggle} className="flex-1 flex items-center gap-4 text-left min-w-0">
        <div
          className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0 transition-all ${
            isCompleted ? "bg-primary/10" : "bg-muted"
          }`}
        >
          {isCompleted ? (
            <motion.div
              initial={{ scale: 0, rotate: -45 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ type: "spring", stiffness: 500, damping: 15 }}
              className="w-8 h-8 rounded-xl bg-primary flex items-center justify-center"
            >
              <Check className="w-5 h-5 text-primary-foreground" strokeWidth={3} />
            </motion.div>
          ) : (
            <span>{habit.emoji}</span>
          )}
        </div>

        <div className="flex-1 min-w-0">
          <p className={`font-display font-semibold truncate ${isCompleted ? "line-through text-muted-foreground" : "text-foreground"}`}>
            {habit.title}
          </p>
          <p className="text-xs text-muted-foreground font-body">
            +{habit.points_per_completion} XP · {habit.current_streak} day streak
          </p>
        </div>
      </button>

      <button
        onClick={handleCameraClick}
        disabled={uploading}
        className={`flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center transition-all overflow-hidden ${
          proofPhotoUrl
            ? "bg-primary/10 text-primary"
            : "bg-muted text-muted-foreground hover:bg-primary/10 hover:text-primary"
        }`}
        title={proofPhotoUrl ? "Replace proof photo" : "Add proof photo"}
      >
        {uploading ? (
          <Loader2 className="w-4 h-4 animate-spin" />
        ) : proofPhotoUrl ? (
          <img src={proofPhotoUrl} alt="Proof" className="w-full h-full object-cover" />
        ) : (
          <Camera className="w-4 h-4" />
        )}
      </button>
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleFileChange}
        className="hidden"
      />

      <AnimatePresence>
        {justCompleted && (
          <motion.div
            initial={{ opacity: 0, scale: 0.3, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.5, y: -10 }}
            transition={{ type: "spring", stiffness: 400, damping: 12 }}
            className="absolute -top-3 -right-3 bg-accent text-accent-foreground text-xs font-bold rounded-full px-3 py-1.5 flex items-center gap-1 shadow-lg z-10"
          >
            <Sparkles className="w-3.5 h-3.5" />
            +{habit.points_per_completion} XP
          </motion.div>
        )}
        {milestoneHit && (
          <motion.div
            initial={{ opacity: 0, scale: 0.3, y: -10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.5 }}
            transition={{ type: "spring", stiffness: 300, damping: 10 }}
            className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-orange-400 to-red-500 text-white text-xs font-bold rounded-full px-3 py-1.5 flex items-center gap-1 shadow-lg z-10 whitespace-nowrap"
          >
            🔥 {milestoneHit} day streak!
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}