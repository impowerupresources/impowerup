import React from "react";
import { motion } from "framer-motion";
import { Clock, Sparkles, Bell, Calendar } from "lucide-react";
import HabitProofButton from "@/components/planner/HabitProofButton";

const TYPE_STYLES = {
  habit: { bg: "bg-primary/10 border-primary/30", icon: Sparkles, iconColor: "text-primary", dot: "bg-primary" },
  reminder: { bg: "bg-destructive/10 border-destructive/30", icon: Bell, iconColor: "text-destructive", dot: "bg-destructive" },
  event: { bg: "bg-secondary/10 border-secondary/30", icon: Calendar, iconColor: "text-secondary", dot: "bg-secondary" },
};

export default function DayTimeline({ blocks = [], habits = [], reminders = [], date, logs = [], onAddProof }) {
  const sorted = [...blocks].sort((a, b) => a.time.localeCompare(b.time));

  if (sorted.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground font-body text-sm">
        No time blocks in this template yet.
      </div>
    );
  }

  return (
    <div className="relative pl-8">
      {/* Vertical line */}
      <div className="absolute left-3 top-0 bottom-0 w-0.5 bg-border rounded-full" />

      <div className="space-y-4">
        {sorted.map((block, i) => {
          const style = TYPE_STYLES[block.type] || TYPE_STYLES.event;
          const Icon = style.icon;

          let label = block.label;
          if (block.type === "habit" && block.habit_id) {
            const h = habits.find((h) => h.id === block.habit_id);
            if (h) label = `${h.emoji} ${h.title}`;
          }
          if (block.type === "reminder" && block.reminder_id) {
            const r = reminders.find((r) => r.id === block.reminder_id);
            if (r) label = r.title;
          }

          return (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -16 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.06 }}
              className="relative flex items-start gap-3"
            >
              {/* Dot */}
              <div className={`absolute -left-8 top-3 w-3 h-3 rounded-full border-2 border-card ${style.dot} flex-shrink-0`} />

              <div className={`flex-1 border rounded-2xl p-3 ${style.bg}`}>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-display font-bold text-muted-foreground flex items-center gap-1">
                    <Clock className="w-3 h-3" />{block.time}
                  </span>
                  {block.duration_minutes && (
                    <span className="text-xs text-muted-foreground font-body">· {block.duration_minutes}min</span>
                  )}
                </div>
                <p className="font-display font-semibold text-sm text-foreground mt-0.5">{label || "—"}</p>
                <div className="flex items-center gap-1 mt-1">
                  <Icon className={`w-3 h-3 ${style.iconColor}`} />
                  <span className={`text-xs font-body capitalize ${style.iconColor}`}>{block.type}</span>
                </div>
                {block.type === "habit" && block.habit_id && (
                  <HabitProofButton
                    isCompleted={!!logs.find((l) => l.habit_id === block.habit_id)}
                    proofPhotoUrl={logs.find((l) => l.habit_id === block.habit_id)?.proof_photo_url}
                    onUpload={(file) => onAddProof?.(habits.find((h) => h.id === block.habit_id), file)}
                  />
                )}
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}