import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { X, Plus, Trash2, GripVertical, Clock } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const TEMPLATE_EMOJIS = ["📅", "🏫", "🏠", "🌅", "🌙", "💼", "🎓", "⚡", "🎯", "🧘"];
const COLORS = ["#8B5CF6", "#06B6D4", "#F59E0B", "#EF4444", "#10B981", "#3B82F6", "#EC4899", "#F97316"];

export default function TemplateForm({ template, habits, reminders, onSubmit, onCancel }) {
  const [form, setForm] = useState({
    name: template?.name || "",
    description: template?.description || "",
    emoji: template?.emoji || "📅",
    color: template?.color || "#8B5CF6",
    time_blocks: template?.time_blocks || [],
  });

  const addBlock = () => {
    setForm({
      ...form,
      time_blocks: [
        ...form.time_blocks,
        { label: "", time: "09:00", duration_minutes: 30, type: "event", habit_id: "", reminder_id: "" },
      ],
    });
  };

  const updateBlock = (i, key, value) => {
    const blocks = [...form.time_blocks];
    blocks[i] = { ...blocks[i], [key]: value };
    // Auto-fill label from linked habit/reminder
    if (key === "habit_id") {
      const h = habits.find((h) => h.id === value);
      if (h) blocks[i].label = h.title;
      blocks[i].type = "habit";
    }
    if (key === "reminder_id") {
      const r = reminders.find((r) => r.id === value);
      if (r) blocks[i].label = r.title;
      blocks[i].type = "reminder";
    }
    setForm({ ...form, time_blocks: blocks });
  };

  const removeBlock = (i) => {
    setForm({ ...form, time_blocks: form.time_blocks.filter((_, idx) => idx !== i) });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name.trim()) return;
    onSubmit(form);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="bg-card rounded-3xl border border-border p-6 shadow-lg"
    >
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-display font-bold text-lg">{template ? "Edit Template" : "New Schedule Template"}</h3>
        <Button variant="ghost" size="icon" onClick={onCancel} className="rounded-xl"><X className="w-5 h-5" /></Button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="flex gap-3">
          <div className="flex-1">
            <Label className="font-body font-semibold text-sm">Template Name</Label>
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Class Schedule A Day" className="mt-1 rounded-xl" />
          </div>
        </div>

        <div>
          <Label className="font-body font-semibold text-sm mb-2 block">Emoji & Color</Label>
          <div className="flex flex-wrap gap-2 mb-2">
            {TEMPLATE_EMOJIS.map((e) => (
              <button key={e} type="button" onClick={() => setForm({ ...form, emoji: e })}
                className={`w-9 h-9 rounded-xl text-lg flex items-center justify-center transition-all ${form.emoji === e ? "ring-2 ring-primary bg-primary/10 scale-110" : "bg-muted"}`}>
                {e}
              </button>
            ))}
          </div>
          <div className="flex gap-2">
            {COLORS.map((c) => (
              <button key={c} type="button" onClick={() => setForm({ ...form, color: c })}
                className={`w-7 h-7 rounded-full transition-all ${form.color === c ? "ring-2 ring-offset-2 ring-foreground scale-110" : ""}`}
                style={{ backgroundColor: c }} />
            ))}
          </div>
        </div>

        <div>
          <Label className="font-body font-semibold text-sm">Description</Label>
          <Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="When do you use this schedule?" className="mt-1 rounded-xl" />
        </div>

        {/* Time blocks */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <Label className="font-body font-semibold text-sm">Time Blocks</Label>
            <Button type="button" variant="outline" size="sm" onClick={addBlock} className="rounded-xl text-xs">
              <Plus className="w-3.5 h-3.5 mr-1" /> Add Block
            </Button>
          </div>

          <AnimatePresence>
            {form.time_blocks.length === 0 && (
              <p className="text-xs text-muted-foreground font-body text-center py-4 bg-muted rounded-2xl">
                Add time blocks to schedule habits, reminders, or custom events.
              </p>
            )}
            {form.time_blocks.map((block, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                className="mb-3 bg-muted/60 rounded-2xl p-4 space-y-3">
                <div className="flex items-center gap-2">
                  <GripVertical className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  <div className="flex-1 grid grid-cols-2 gap-2">
                    <div>
                      <p className="text-xs font-body font-semibold text-muted-foreground mb-1">Type</p>
                      <Select value={block.type} onValueChange={(v) => updateBlock(i, "type", v)}>
                        <SelectTrigger className="h-9 rounded-xl text-sm"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="event">Custom Event</SelectItem>
                          <SelectItem value="habit">Habit</SelectItem>
                          <SelectItem value="reminder">Reminder</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <p className="text-xs font-body font-semibold text-muted-foreground mb-1 flex items-center gap-1"><Clock className="w-3 h-3" /> Time</p>
                      <Input type="time" value={block.time} onChange={(e) => updateBlock(i, "time", e.target.value)} className="h-9 rounded-xl text-sm" />
                    </div>
                  </div>
                  <Button type="button" variant="ghost" size="icon" onClick={() => removeBlock(i)} className="rounded-xl h-8 w-8 text-destructive flex-shrink-0">
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>

                {block.type === "habit" && (
                  <Select value={block.habit_id} onValueChange={(v) => updateBlock(i, "habit_id", v)}>
                    <SelectTrigger className="h-9 rounded-xl text-sm"><SelectValue placeholder="Choose a habit" /></SelectTrigger>
                    <SelectContent>
                      {habits.map((h) => <SelectItem key={h.id} value={h.id}>{h.emoji} {h.title}</SelectItem>)}
                    </SelectContent>
                  </Select>
                )}

                {block.type === "reminder" && (
                  <Select value={block.reminder_id} onValueChange={(v) => updateBlock(i, "reminder_id", v)}>
                    <SelectTrigger className="h-9 rounded-xl text-sm"><SelectValue placeholder="Choose a reminder" /></SelectTrigger>
                    <SelectContent>
                      {reminders.map((r) => <SelectItem key={r.id} value={r.id}>🔔 {r.title}</SelectItem>)}
                    </SelectContent>
                  </Select>
                )}

                {block.type === "event" && (
                  <Input value={block.label} onChange={(e) => updateBlock(i, "label", e.target.value)} placeholder="Event label (e.g. Lunch Break)" className="h-9 rounded-xl text-sm" />
                )}

                <div>
                  <p className="text-xs font-body font-semibold text-muted-foreground mb-1">Duration (minutes)</p>
                  <Input type="number" min={5} step={5} value={block.duration_minutes} onChange={(e) => updateBlock(i, "duration_minutes", parseInt(e.target.value) || 30)} className="h-9 rounded-xl text-sm w-28" />
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        <div className="flex gap-3 pt-2">
          <Button type="button" variant="outline" onClick={onCancel} className="flex-1 rounded-2xl font-body font-semibold">Cancel</Button>
          <Button type="submit" className="flex-1 rounded-2xl font-body font-semibold">{template ? "Save" : "Create Template"}</Button>
        </div>
      </form>
    </motion.div>
  );
}