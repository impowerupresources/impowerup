import React from "react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isSameMonth, startOfWeek, endOfWeek } from "date-fns";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function MiniCalendar({ currentMonth, selectedDate, onSelectDate, onPrevMonth, onNextMonth, dayPlans = [], templates = [] }) {
  const start = startOfWeek(startOfMonth(currentMonth), { weekStartsOn: 1 });
  const end = endOfWeek(endOfMonth(currentMonth), { weekStartsOn: 1 });
  const days = eachDayOfInterval({ start, end });
  const WEEKDAYS = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];

  const getTemplate = (day) => {
    const dateStr = format(day, "yyyy-MM-dd");
    const plan = dayPlans.find((p) => p.date === dateStr);
    if (!plan?.template_id) return null;
    return templates.find((t) => t.id === plan.template_id);
  };

  return (
    <div className="bg-card rounded-3xl border border-border p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display font-bold text-base">{format(currentMonth, "MMMM yyyy")}</h3>
        <div className="flex gap-1">
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-xl" onClick={onPrevMonth}><ChevronLeft className="w-4 h-4" /></Button>
          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-xl" onClick={onNextMonth}><ChevronRight className="w-4 h-4" /></Button>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-1 mb-2">
        {WEEKDAYS.map((d) => (
          <p key={d} className="text-center text-xs font-body font-bold text-muted-foreground py-1">{d}</p>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-1">
        {days.map((day) => {
          const tmpl = getTemplate(day);
          const isSelected = isSameDay(day, selectedDate);
          const isToday = isSameDay(day, new Date());
          const inMonth = isSameMonth(day, currentMonth);

          return (
            <motion.button
              key={day.toISOString()}
              whileTap={{ scale: 0.9 }}
              onClick={() => onSelectDate(day)}
              className={`relative flex flex-col items-center justify-center h-9 rounded-xl text-xs font-body font-semibold transition-all ${
                isSelected
                  ? "bg-primary text-primary-foreground"
                  : isToday
                  ? "bg-primary/10 text-primary"
                  : inMonth
                  ? "hover:bg-muted text-foreground"
                  : "text-muted-foreground/40"
              }`}
            >
              {format(day, "d")}
              {tmpl && (
                <div className="absolute bottom-0.5 w-1.5 h-1.5 rounded-full" style={{ backgroundColor: tmpl.color }} />
              )}
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}