import React, { useRef, useState } from "react";
import { motion } from "framer-motion";
import { Camera, CheckCircle, Loader2 } from "lucide-react";
import { celebrate } from "@/lib/celebrate";

export default function HabitProofButton({ isCompleted, proofPhotoUrl, onUpload }) {
  const inputRef = useRef(null);
  const [uploading, setUploading] = useState(false);

  const handleChange = async (e) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploading(true);
      const wasNew = await onUpload?.(file);
      setUploading(false);
      if (wasNew) celebrate();
    }
    e.target.value = "";
  };

  if (isCompleted) {
    return (
      <div className="flex items-center gap-2 mt-2">
        <CheckCircle className="w-4 h-4 text-green-500 shrink-0" />
        {proofPhotoUrl && (
          <img src={proofPhotoUrl} alt="Proof" className="w-10 h-10 rounded-lg object-cover border border-border" />
        )}
        <button
          onClick={() => inputRef.current?.click()}
          disabled={uploading}
          className="text-xs text-primary font-body font-semibold hover:underline"
        >
          {uploading ? "Uploading..." : "Update photo"}
        </button>
        <input ref={inputRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={handleChange} />
      </div>
    );
  }

  return (
    <motion.button
      whileTap={{ scale: 0.95 }}
      onClick={() => inputRef.current?.click()}
      disabled={uploading}
      className="mt-2 flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-primary/10 text-primary text-xs font-body font-semibold hover:bg-primary/20 transition-colors"
    >
      {uploading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Camera className="w-3.5 h-3.5" />}
      {uploading ? "Uploading..." : "Prove it 📸"}
      <input ref={inputRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={handleChange} />
    </motion.button>
  );
}