import React from "react";
import { ComposedChart, Bar, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { format, subWeeks, startOfWeek, addDays } from "date-fns";

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-card border border-border rounded-2xl px-4 py-2 shadow-lg">
        <p className="font-display font-bold text-sm">{label}</p>
        <p className="text-chart-4 font-body text-sm">{payload[0].value} completions</p>
      </div>
    );
  }
  return null;
};

export default function WeeklyTrendChart({ logs }) {
  const data = Array.from({ length: 8 }, (_, i) => {
    const weekStart = startOfWeek(subWeeks(new Date(), 7 - i), { weekStartsOn: 1 });
    const weekEnd = addDays(weekStart, 6);
    const startStr = format(weekStart, "yyyy-MM-dd");
    const endStr = format(weekEnd, "yyyy-MM-dd");
    const count = logs.filter((l) => l.completed_date >= startStr && l.completed_date <= endStr).length;
    return { week: i === 7 ? "This wk" : format(weekStart, "MMM d"), count };
  });

  const chartData = data.map((d, i) => ({
    ...d,
    trend: i > 0 ? Math.round((data[i].count + data[i - 1].count) / 2) : d.count,
  }));

  return (
    <ResponsiveContainer width="100%" height={200}>
      <ComposedChart data={chartData}>
        <defs>
          <linearGradient id="trendBarGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="hsl(var(--chart-4))" stopOpacity={0.9} />
            <stop offset="100%" stopColor="hsl(var(--chart-4))" stopOpacity={0.4} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
        <XAxis dataKey="week" tick={{ fontSize: 10, fontFamily: "var(--font-body)", fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
        <YAxis hide allowDecimals={false} />
        <Tooltip content={<CustomTooltip />} cursor={{ fill: "hsl(var(--muted))", radius: 8 }} />
        <Bar dataKey="count" fill="url(#trendBarGradient)" radius={[8, 8, 0, 0]} barSize={24} />
        <Line type="monotone" dataKey="trend" stroke="hsl(var(--primary))" strokeWidth={2.5} dot={false} />
      </ComposedChart>
    </ResponsiveContainer>
  );
}