import React from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Area, AreaChart } from "recharts";
import { format, subDays } from "date-fns";

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-card border border-border rounded-2xl px-4 py-2 shadow-lg">
        <p className="font-display font-bold text-sm">{label}</p>
        <p className="text-secondary font-body text-sm">{payload[0].value}% completion</p>
      </div>
    );
  }
  return null;
};

export default function CompletionLineChart({ logs, habitCount }) {
  const data = Array.from({ length: 28 }, (_, i) => {
    const d = subDays(new Date(), 27 - i);
    const dateStr = format(d, "yyyy-MM-dd");
    const count = logs.filter((l) => l.completed_date === dateStr).length;
    const rate = habitCount > 0 ? Math.round((count / habitCount) * 100) : 0;
    return { day: format(d, "MMM d"), rate };
  });

  return (
    <ResponsiveContainer width="100%" height={180}>
      <AreaChart data={data}>
        <defs>
          <linearGradient id="rateGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="hsl(var(--secondary))" stopOpacity={0.3} />
            <stop offset="95%" stopColor="hsl(var(--secondary))" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
        <XAxis dataKey="day" tick={{ fontSize: 10, fontFamily: "var(--font-body)", fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} interval={6} />
        <YAxis hide domain={[0, 100]} />
        <Tooltip content={<CustomTooltip />} />
        <Area type="monotone" dataKey="rate" stroke="hsl(var(--secondary))" strokeWidth={2.5} fill="url(#rateGradient)" dot={false} />
      </AreaChart>
    </ResponsiveContainer>
  );
}