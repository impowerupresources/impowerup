import React from "react";
import { Flame, Trophy } from "lucide-react";
import { motion } from "framer-motion";

export default function HabitStreakList({ habits, logs }) {
  const sorted = [...habits].sort((a, b) => (b.current_streak || 0) - (a.current_streak || 0));

  return (
    <div className="space-y-3">
      {sorted.map((habit, i) => {
        const total = logs.filter((l) => l.habit_id === habit.id).length;
        const maxStreak = habit.best_streak || 0;
        const pct = maxStreak > 0 ? Math.min(100, Math.round(((habit.current_streak || 0) / maxStreak) * 100)) : 0;
        return (
          <motion.div
            key={habit.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.05 }}
            className="flex items-center gap-3"
          >
            <span className="text-xl w-8 text-center">{habit.emoji}</span>
            <div className="flex-1 min-w-0">
              <div className="flex justify-between text-sm mb-1">
                <span className="font-body font-semibold text-foreground truncate">{habit.title}</span>
                <span className="font-body text-muted-foreground text-xs ml-2 whitespace-nowrap">{total} total</span>
              </div>
              <div className="h-2.5 bg-muted rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-primary to-secondary rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${pct}%` }}
                  transition={{ duration: 0.8, ease: "easeOut" }}
                />
              </div>
            </div>
            <div className="flex items-center gap-1 text-accent-foreground bg-accent/10 rounded-xl px-2 py-1 text-xs font-bold font-display whitespace-nowrap">
              <Flame className="w-3 h-3" />
              {habit.current_streak || 0}d
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}