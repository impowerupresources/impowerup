import React from "react";
import { motion } from "framer-motion";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Pencil, Trash2, Calendar } from "lucide-react";
import { format } from "date-fns";

export default function GoalCard({ goal, onToggleMilestone, onEdit, onDelete }) {
  const completedCount = (goal.milestones || []).filter((m) => m.completed).length;
  const totalCount = (goal.milestones || []).length;
  const progress = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : goal.progress || 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card rounded-3xl border border-border p-5 shadow-sm"
    >
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 rounded-2xl bg-secondary/10 flex items-center justify-center text-2xl flex-shrink-0">
          {goal.emoji || "🎯"}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between">
            <div>
              <h3 className="font-display font-bold text-foreground">{goal.title}</h3>
              {goal.target_date && (
                <p className="text-xs text-muted-foreground font-body flex items-center gap-1 mt-1">
                  <Calendar className="w-3 h-3" />
                  {format(new Date(goal.target_date), "MMM d, yyyy")}
                </p>
              )}
            </div>
            <div className="flex gap-1">
              <Button variant="ghost" size="icon" onClick={() => onEdit(goal)} className="rounded-xl h-8 w-8">
                <Pencil className="w-3.5 h-3.5" />
              </Button>
              <Button variant="ghost" size="icon" onClick={() => onDelete(goal.id)} className="rounded-xl h-8 w-8 text-destructive">
                <Trash2 className="w-3.5 h-3.5" />
              </Button>
            </div>
          </div>

          {goal.description && (
            <p className="text-sm text-muted-foreground font-body mt-2">{goal.description}</p>
          )}

          <div className="mt-4">
            <div className="flex justify-between text-xs font-body font-semibold mb-1.5">
              <span className="text-secondary">{progress}% complete</span>
              <span className="text-muted-foreground">{completedCount}/{totalCount} milestones</span>
            </div>
            <div className="h-3 bg-muted rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-secondary to-primary rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.8, ease: "easeOut" }}
              />
            </div>
          </div>

          {(goal.milestones || []).length > 0 && (
            <div className="mt-4 space-y-2">
              {goal.milestones.map((m, i) => (
                <label key={i} className="flex items-center gap-3 cursor-pointer group">
                  <Checkbox
                    checked={m.completed}
                    onCheckedChange={() => onToggleMilestone(goal, i)}
                    className="rounded-md data-[state=checked]:bg-secondary data-[state=checked]:border-secondary"
                  />
                  <span className={`text-sm font-body transition-all ${m.completed ? "line-through text-muted-foreground" : "text-foreground group-hover:text-primary"}`}>
                    {m.title}
                  </span>
                </label>
              ))}
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}