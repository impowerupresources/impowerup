import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { motion } from "framer-motion";
import { X, Plus, Trash2 } from "lucide-react";
import AlarmSettings from "@/components/reminders/AlarmSettings";

const GOAL_EMOJIS = ["🎯", "🏆", "🚀", "📈", "💡", "🌟", "🏅", "🎓", "💪", "🧩", "🎨", "🌈"];

export default function GoalForm({ goal, linkedReminder, onSubmit, onCancel }) {
  const [form, setForm] = useState({
    title: goal?.title || "",
    description: goal?.description || "",
    emoji: goal?.emoji || "🎯",
    target_date: goal?.target_date || "",
    milestones: goal?.milestones || [],
    alarm: linkedReminder
      ? {
          enabled: true,
          time: linkedReminder.time || "09:00",
          days: linkedReminder.days || ["Mon", "Tue", "Wed", "Thu", "Fri"],
          alarm_level: linkedReminder.alarm_level || "moderate",
          snooze_allowed: linkedReminder.snooze_allowed ?? false,
          max_snoozes: linkedReminder.max_snoozes || 0,
          message: linkedReminder.message || "",
        }
      : { enabled: false, time: "09:00", days: ["Mon", "Tue", "Wed", "Thu", "Fri"], alarm_level: "moderate", snooze_allowed: false, max_snoozes: 0, message: "" },
  });
  const [newMilestone, setNewMilestone] = useState("");

  const addMilestone = () => {
    if (!newMilestone.trim()) return;
    setForm({ ...form, milestones: [...form.milestones, { title: newMilestone, completed: false }] });
    setNewMilestone("");
  };

  const removeMilestone = (index) => {
    setForm({ ...form, milestones: form.milestones.filter((_, i) => i !== index) });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.title.trim()) return;
    const progress = form.milestones.length > 0
      ? Math.round((form.milestones.filter((m) => m.completed).length / form.milestones.length) * 100)
      : 0;
    onSubmit({ ...form, progress });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="bg-card rounded-3xl border border-border p-6 shadow-lg"
    >
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-display font-bold text-lg">{goal ? "Edit Goal" : "New Goal"}</h3>
        <Button variant="ghost" size="icon" onClick={onCancel} className="rounded-xl">
          <X className="w-5 h-5" />
        </Button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <Label className="font-body font-semibold text-sm mb-2 block">Pick an emoji</Label>
          <div className="flex flex-wrap gap-2">
            {GOAL_EMOJIS.map((e) => (
              <button
                key={e}
                type="button"
                onClick={() => setForm({ ...form, emoji: e })}
                className={`w-10 h-10 rounded-xl text-lg flex items-center justify-center transition-all ${
                  form.emoji === e ? "bg-secondary/10 ring-2 ring-secondary scale-110" : "bg-muted hover:bg-muted/80"
                }`}
              >
                {e}
              </button>
            ))}
          </div>
        </div>

        <div>
          <Label className="font-body font-semibold text-sm">Goal Title</Label>
          <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="e.g., Learn to play guitar" className="mt-1 rounded-xl" />
        </div>

        <div>
          <Label className="font-body font-semibold text-sm">Description</Label>
          <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="What does success look like?" className="mt-1 rounded-xl h-20" />
        </div>

        <div>
          <Label className="font-body font-semibold text-sm">Target Date</Label>
          <Input type="date" value={form.target_date} onChange={(e) => setForm({ ...form, target_date: e.target.value })} className="mt-1 rounded-xl" />
        </div>

        <div>
          <Label className="font-body font-semibold text-sm mb-2 block">Milestones</Label>
          <div className="space-y-2 mb-3">
            {form.milestones.map((m, i) => (
              <div key={i} className="flex items-center gap-2 bg-muted rounded-xl p-2 px-3">
                <span className="text-sm font-body flex-1">{m.title}</span>
                <Button type="button" variant="ghost" size="icon" onClick={() => removeMilestone(i)} className="h-7 w-7 rounded-lg">
                  <Trash2 className="w-3 h-3 text-destructive" />
                </Button>
              </div>
            ))}
          </div>
          <div className="flex gap-2">
            <Input
              value={newMilestone}
              onChange={(e) => setNewMilestone(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addMilestone())}
              placeholder="Add a milestone..."
              className="rounded-xl"
            />
            <Button type="button" variant="outline" onClick={addMilestone} className="rounded-xl">
              <Plus className="w-4 h-4" />
            </Button>
          </div>
        </div>

        <AlarmSettings value={form.alarm} onChange={(alarm) => setForm({ ...form, alarm })} />

        <div className="flex gap-3 pt-2">
          <Button type="button" variant="outline" onClick={onCancel} className="flex-1 rounded-2xl font-body font-semibold">Cancel</Button>
          <Button type="submit" className="flex-1 rounded-2xl font-body font-semibold bg-secondary hover:bg-secondary/90">{goal ? "Save Changes" : "Create Goal"}</Button>
        </div>
      </form>
    </motion.div>
  );
}