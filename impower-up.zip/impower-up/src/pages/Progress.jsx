import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { TrendingUp, Zap, Flame, Calendar } from "lucide-react";
import { motion } from "framer-motion";
import { subDays, format } from "date-fns";
import WeeklyBarChart from "@/components/progress/WeeklyBarChart";
import CompletionLineChart from "@/components/progress/CompletionLineChart";
import WeeklyTrendChart from "@/components/progress/WeeklyTrendChart";
import HabitStreakList from "@/components/progress/HabitStreakList";

export default function Progress() {
  const { data: habits = [] } = useQuery({
    queryKey: ["habits-all"],
    queryFn: () => base44.entities.Habit.list(),
  });
  const { data: logs = [] } = useQuery({
    queryKey: ["habit-logs"],
    queryFn: () => base44.entities.HabitLog.list("-completed_date", 500),
  });

  const totalPoints = logs.reduce((s, l) => s + (l.points_earned || 0), 0);
  const weekAgo = format(subDays(new Date(), 7), "yyyy-MM-dd");
  const weeklyLogs = logs.filter((l) => l.completed_date >= weekAgo);
  const today = format(new Date(), "yyyy-MM-dd");
  const todayCount = logs.filter((l) => l.completed_date === today).length;
  const bestStreak = Math.max(0, ...habits.map((h) => h.best_streak || 0));

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 md:py-10 space-y-6">
      <motion.h1 initial={{ opacity: 0, y: -16 }} animate={{ opacity: 1, y: 0 }} className="text-2xl md:text-3xl font-display font-bold text-foreground">
        Progress 📊
      </motion.h1>

      {/* Quick stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { icon: Zap, label: "Total XP", value: totalPoints, color: "bg-primary/10 text-primary" },
          { icon: Calendar, label: "This Week", value: weeklyLogs.length, color: "bg-secondary/10 text-secondary" },
          { icon: Flame, label: "Best Streak", value: `${bestStreak}d`, color: "bg-accent/10 text-accent-foreground" },
          { icon: TrendingUp, label: "Today", value: `${todayCount}/${habits.length}`, color: "bg-chart-4/10 text-chart-4" },
        ].map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }} className="bg-card rounded-2xl border border-border p-4">
            <div className={`w-9 h-9 rounded-xl ${s.color} flex items-center justify-center mb-2`}>
              <s.icon className="w-4 h-4" />
            </div>
            <p className="text-2xl font-display font-bold">{s.value}</p>
            <p className="text-xs text-muted-foreground font-body">{s.label}</p>
          </motion.div>
        ))}
      </div>

      {/* Weekly bar */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-card rounded-3xl border border-border p-5">
        <h2 className="font-display font-bold text-base mb-4">Habits Completed — Last 7 Days</h2>
        <WeeklyBarChart logs={logs} />
      </motion.div>

      {/* 8-week weekly trend */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.12 }} className="bg-card rounded-3xl border border-border p-5">
        <h2 className="font-display font-bold text-base mb-1">Weekly Trend — Last 8 Weeks</h2>
        <p className="text-xs text-muted-foreground font-body mb-4">See if you're improving week over week</p>
        <WeeklyTrendChart logs={logs} />
      </motion.div>

      {/* 28-day completion trend */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} className="bg-card rounded-3xl border border-border p-5">
        <h2 className="font-display font-bold text-base mb-1">Completion Rate — Last 28 Days</h2>
        <p className="text-xs text-muted-foreground font-body mb-4">% of habits done each day</p>
        <CompletionLineChart logs={logs} habitCount={habits.length} />
      </motion.div>

      {/* Per-habit streaks */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-card rounded-3xl border border-border p-5">
        <h2 className="font-display font-bold text-base mb-4">Habit Streaks</h2>
        {habits.length === 0 ? (
          <p className="text-muted-foreground font-body text-sm text-center py-6">No habits yet — create some to see your streaks!</p>
        ) : (
          <HabitStreakList habits={habits} logs={logs} />
        )}
      </motion.div>
    </div>
  );
}