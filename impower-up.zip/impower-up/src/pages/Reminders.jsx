import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Bell, BellOff, Pencil, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { AnimatePresence, motion } from "framer-motion";
import ReminderForm from "@/components/reminders/ReminderForm";
import { Badge } from "@/components/ui/badge";

const LEVEL_COLORS = {
  gentle: "bg-chart-5/10 text-chart-5",
  moderate: "bg-primary/10 text-primary",
  loud: "bg-accent/10 text-accent-foreground",
  persistent: "bg-destructive/10 text-destructive",
};

export default function Reminders() {
  const [showForm, setShowForm] = useState(false);
  const [editingReminder, setEditingReminder] = useState(null);
  const queryClient = useQueryClient();

  const { data: reminders = [] } = useQuery({
    queryKey: ["reminders"],
    queryFn: () => base44.entities.Reminder.list("-created_date"),
  });

  const { data: habits = [] } = useQuery({
    queryKey: ["habits"],
    queryFn: () => base44.entities.Habit.filter({ is_active: true }),
  });

  const { data: goals = [] } = useQuery({
    queryKey: ["goals"],
    queryFn: () => base44.entities.Goal.filter({ status: "active" }),
  });

  const createReminder = useMutation({
    mutationFn: (data) => base44.entities.Reminder.create(data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["reminders"] }); setShowForm(false); },
  });

  const updateReminder = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Reminder.update(id, data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["reminders"] }); setEditingReminder(null); setShowForm(false); },
  });

  const deleteReminder = useMutation({
    mutationFn: (id) => base44.entities.Reminder.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["reminders"] }),
  });

  const handleSubmit = (data) => {
    if (editingReminder) {
      updateReminder.mutate({ id: editingReminder.id, data });
    } else {
      createReminder.mutate(data);
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 md:py-10 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl md:text-3xl font-display font-bold text-foreground">Reminders 🔔</h1>
        <Button onClick={() => { setEditingReminder(null); setShowForm(true); }} className="rounded-2xl font-body font-semibold">
          <Plus className="w-4 h-4 mr-2" /> New Reminder
        </Button>
      </div>

      <p className="text-sm text-muted-foreground font-body -mt-2">
        Alarms are set up directly from your habits, goals, and planner — and fire automatically across the whole app.
      </p>

      <AnimatePresence>
        {showForm && (
          <ReminderForm
            reminder={editingReminder}
            habits={habits}
            onSubmit={handleSubmit}
            onCancel={() => { setShowForm(false); setEditingReminder(null); }}
          />
        )}
      </AnimatePresence>

      {reminders.length === 0 && !showForm ? (
        <div className="text-center py-16 bg-card rounded-3xl border-2 border-dashed border-border">
          <p className="text-5xl mb-4">⏰</p>
          <p className="font-display font-bold text-xl text-foreground mb-2">No reminders yet!</p>
          <p className="text-sm text-muted-foreground font-body mb-6 max-w-xs mx-auto">
            Set up alarms from your habits, goals, or planner — or create a standalone reminder here.
          </p>
          <Button onClick={() => setShowForm(true)} className="rounded-2xl font-body font-semibold">
            <Plus className="w-4 h-4 mr-2" /> Create Reminder
          </Button>
        </div>
      ) : (
        <div className="space-y-3">
          {reminders.map((reminder, i) => {
            const linkedHabit = habits.find((h) => h.id === reminder.habit_id);
            const linkedGoal = goals.find((g) => g.id === reminder.goal_id);
            return (
              <motion.div
                key={reminder.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className={`bg-card rounded-2xl border border-border p-4 transition-opacity ${!reminder.is_active ? "opacity-50" : ""}`}
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                    {reminder.is_active ? <Bell className="w-5 h-5 text-primary" /> : <BellOff className="w-5 h-5 text-muted-foreground" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-display font-semibold text-foreground truncate">{reminder.title}</p>
                    <div className="flex items-center gap-2 mt-1 flex-wrap">
                      <span className="text-lg font-display font-bold text-primary">{reminder.time}</span>
                      <Badge variant="secondary" className={`rounded-lg text-xs font-body ${LEVEL_COLORS[reminder.alarm_level]}`}>
                        {reminder.alarm_level}
                      </Badge>
                      {linkedHabit && (
                        <span className="text-xs text-muted-foreground font-body">{linkedHabit.emoji} {linkedHabit.title}</span>
                      )}
                      {linkedGoal && (
                        <span className="text-xs text-muted-foreground font-body">{linkedGoal.emoji || "🎯"} {linkedGoal.title}</span>
                      )}
                    </div>
                    <div className="flex gap-1 mt-1.5">
                      {(reminder.days || []).map((d) => (
                        <span key={d} className="text-[10px] font-body font-bold text-muted-foreground bg-muted rounded-md px-1.5 py-0.5">{d}</span>
                      ))}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={reminder.is_active}
                      onCheckedChange={(v) => updateReminder.mutate({ id: reminder.id, data: { is_active: v } })}
                    />
                    <Button variant="ghost" size="icon" className="rounded-xl h-8 w-8" onClick={() => { setEditingReminder(reminder); setShowForm(true); }}>
                      <Pencil className="w-3.5 h-3.5" />
                    </Button>
                    <Button variant="ghost" size="icon" className="rounded-xl h-8 w-8 text-destructive" onClick={() => deleteReminder.mutate(reminder.id)}>
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}