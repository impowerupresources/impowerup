import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Users, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import SessionForm from "@/components/bodydoubling/SessionForm";
import ActiveSession from "@/components/bodydoubling/ActiveSession";
import SessionCard from "@/components/bodydoubling/SessionCard";

export default function BodyDoubling() {
  const queryClient = useQueryClient();
  const [showForm, setShowForm] = useState(false);

  const { data: activeSession } = useQuery({
    queryKey: ["bd-active"],
    queryFn: async () => {
      const sessions = await base44.entities.BodyDoubleSession.filter({ status: "active" });
      return sessions[0] || null;
    },
  });

  const { data: completedSessions = [] } = useQuery({
    queryKey: ["bd-completed"],
    queryFn: () => base44.entities.BodyDoubleSession.filter({ status: "completed" }, "-end_time", 20),
  });

  const createSession = useMutation({
    mutationFn: async (data) => {
      const llmRes = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a body doubling partner for a focus session. The user will work on: "${data.intention}" for ${data.duration_minutes} minutes. Generate a supportive, accountability-focused greeting (2-3 sentences) that makes them feel seen and motivated to follow through. Also pick a friendly first name for yourself. Be warm but firm about accountability.`,
        response_json_schema: {
          type: "object",
          properties: {
            name: { type: "string" },
            greeting: { type: "string" },
          },
        },
      });

      return base44.entities.BodyDoubleSession.create({
        intention: data.intention,
        duration_minutes: data.duration_minutes,
        status: "active",
        partner_name: llmRes.name,
        partner_greeting: llmRes.greeting,
        start_time: new Date().toISOString(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["bd-active"] });
      setShowForm(false);
    },
  });

  const completeSession = useMutation({
    mutationFn: async ({ session, completionNote, mood }) => {
      const llmRes = await base44.integrations.Core.InvokeLLM({
        prompt: `You are ${session.partner_name}, a body doubling partner. The user just finished a ${session.duration_minutes}-minute focus session working on: "${session.intention}". They reported: "${completionNote}". Their mood: ${mood}. Respond with a brief, supportive message (2-3 sentences) acknowledging their effort and what they accomplished.`,
        response_json_schema: {
          type: "object",
          properties: {
            response: { type: "string" },
          },
        },
      });

      return base44.entities.BodyDoubleSession.update(session.id, {
        status: "completed",
        end_time: new Date().toISOString(),
        completion_note: completionNote,
        mood,
        partner_response: llmRes.response,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["bd-active"] });
      queryClient.invalidateQueries({ queryKey: ["bd-completed"] });
    },
  });

  const cancelSession = useMutation({
    mutationFn: (session) =>
      base44.entities.BodyDoubleSession.update(session.id, {
        status: "cancelled",
        end_time: new Date().toISOString(),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["bd-active"] });
    },
  });

  if (activeSession) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-6 md:py-10">
        <ActiveSession
          session={activeSession}
          onComplete={(note, mood) =>
            completeSession.mutate({ session: activeSession, completionNote: note, mood })
          }
          onCancel={() => cancelSession.mutate(activeSession)}
          isCompleting={completeSession.isPending}
        />
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 md:py-10 space-y-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-display font-bold text-foreground flex items-center gap-2">
          <Users className="w-6 h-6 text-primary" /> Focus
        </h1>
        <p className="text-muted-foreground text-sm mt-1">Body doubling for accountability &amp; follow-through</p>
      </div>

      {!showForm && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-card rounded-3xl border border-border p-6 text-center space-y-3"
        >
          <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto">
            <Users className="w-8 h-8 text-primary" />
          </div>
          <h2 className="font-display font-bold text-lg">Work side-by-side</h2>
          <p className="text-sm text-muted-foreground max-w-sm mx-auto">
            Set an intention, get matched with a virtual partner, and work in focused silence together. Check in when you're done.
          </p>
          <Button
            onClick={() => setShowForm(true)}
            className="rounded-2xl font-body font-semibold"
          >
            <Plus className="w-4 h-4 mr-1" /> Start a Session
          </Button>
        </motion.div>
      )}

      {showForm && (
        <SessionForm
          onSubmit={(data) => createSession.mutate(data)}
          onCancel={() => setShowForm(false)}
          isSubmitting={createSession.isPending}
        />
      )}

      {completedSessions.length > 0 && (
        <div>
          <h2 className="font-display font-bold text-lg mb-3">Recent Sessions</h2>
          <div className="space-y-3">
            {completedSessions.map((s, i) => (
              <motion.div
                key={s.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <SessionCard session={s} />
              </motion.div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}