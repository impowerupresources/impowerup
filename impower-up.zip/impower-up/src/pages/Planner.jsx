import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { format, addMonths, subMonths, startOfWeek, addDays } from "date-fns";
import { Plus, Settings2, Trash2, Pencil, ChevronDown, Check, LayoutGrid, CalendarDays, CalendarRange } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AnimatePresence, motion } from "framer-motion";
import { toast } from "sonner";
import { useAuth } from "@/lib/AuthContext";
import MiniCalendar from "@/components/planner/MiniCalendar";
import DayTimeline from "@/components/planner/DayTimeline";
import TemplateForm from "@/components/planner/TemplateForm";

const VIEWS = [
  { key: "day", label: "Day", icon: CalendarDays },
  { key: "week", label: "Week", icon: LayoutGrid },
  { key: "month", label: "Month", icon: CalendarRange },
];

export default function Planner() {
  const [view, setView] = useState("day");
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [showTemplateForm, setShowTemplateForm] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState(null);
  const [showTemplates, setShowTemplates] = useState(false);
  const queryClient = useQueryClient();

  const { data: templates = [] } = useQuery({ queryKey: ["schedule-templates"], queryFn: () => base44.entities.ScheduleTemplate.list() });
  const { data: dayPlans = [] } = useQuery({ queryKey: ["day-plans"], queryFn: () => base44.entities.DayPlan.list("-date", 400) });
  const { data: habits = [] } = useQuery({ queryKey: ["habits"], queryFn: () => base44.entities.Habit.filter({ is_active: true }) });
  const { data: reminders = [] } = useQuery({ queryKey: ["reminders"], queryFn: () => base44.entities.Reminder.list() });
  const { user } = useAuth();
  const selectedDateStr = format(selectedDate, "yyyy-MM-dd");
  const { data: logs = [] } = useQuery({ queryKey: ["planner-logs", selectedDateStr], queryFn: () => base44.entities.HabitLog.filter({ completed_date: selectedDateStr }) });
  const { data: shareLinks = [] } = useQuery({ queryKey: ["share-links"], queryFn: () => base44.entities.ShareLink.filter({ is_active: true }) });

  const notifyMentors = async (habit) => {
    const notifiable = shareLinks.filter((l) => l.notify_on_completion);
    if (notifiable.length === 0) return;
    const userName = user?.nickname || user?.first_name || "your client";
    for (const link of notifiable) {
      try {
        if ((link.notify_method === "email" || link.notify_method === "both") && link.mentor_email) {
          await base44.integrations.Core.SendEmail({
            to: link.mentor_email,
            subject: `Task Completed: ${habit.title} 🎉`,
            body: `Hi ${link.mentor_name},\n\n${userName} just completed "${habit.title}" on ${format(selectedDate, "MMMM d")}.\n\nThey uploaded a photo proof from their planner! 💪`,
          });
        }
        toast.success(`📨 ${link.mentor_name} notified`);
      } catch (err) {}
    }
  };

  const handleAddProof = async (habit, file) => {
    if (!habit) return false;
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const existing = logs.find((l) => l.habit_id === habit.id);
      let isNew = false;
      if (existing) {
        await base44.entities.HabitLog.update(existing.id, { proof_photo_url: file_url });
      } else {
        isNew = true;
        await base44.entities.HabitLog.create({
          habit_id: habit.id,
          completed_date: selectedDateStr,
          points_earned: habit.points_per_completion || 10,
          proof_photo_url: file_url,
        });
        const newStreak = (habit.current_streak || 0) + 1;
        await base44.entities.Habit.update(habit.id, {
          current_streak: newStreak,
          best_streak: Math.max(newStreak, habit.best_streak || 0),
          total_completions: (habit.total_completions || 0) + 1,
        });
        await notifyMentors(habit);
      }
      queryClient.invalidateQueries({ queryKey: ["planner-logs", selectedDateStr] });
      queryClient.invalidateQueries({ queryKey: ["habits"] });
      queryClient.invalidateQueries({ queryKey: ["habit-logs"] });
      toast.success("Proof submitted! 📸");
      return isNew;
    } catch (err) {
      toast.error("Upload failed");
      return false;
    }
  };

  const upsertPlan = useMutation({
    mutationFn: async ({ date, templateId, templateName }) => {
      const existing = dayPlans.find((p) => p.date === date);
      if (existing) {
        return base44.entities.DayPlan.update(existing.id, { template_id: templateId, template_name: templateName });
      }
      return base44.entities.DayPlan.create({ date, template_id: templateId, template_name: templateName });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["day-plans"] });
      toast.success("Schedule applied!");
    },
  });

  const clearPlan = useMutation({
    mutationFn: async (date) => {
      const existing = dayPlans.find((p) => p.date === date);
      if (existing) return base44.entities.DayPlan.delete(existing.id);
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["day-plans"] }),
  });

  const createTemplate = useMutation({
    mutationFn: (data) => editingTemplate ? base44.entities.ScheduleTemplate.update(editingTemplate.id, data) : base44.entities.ScheduleTemplate.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["schedule-templates"] });
      setShowTemplateForm(false);
      setEditingTemplate(null);
      toast.success(editingTemplate ? "Template updated!" : "Template created!");
    },
  });

  const deleteTemplate = useMutation({
    mutationFn: (id) => base44.entities.ScheduleTemplate.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["schedule-templates"] }),
  });

  const getPlanForDate = (date) => {
    const dateStr = typeof date === "string" ? date : format(date, "yyyy-MM-dd");
    return dayPlans.find((p) => p.date === dateStr);
  };

  const getTemplateForDate = (date) => {
    const plan = getPlanForDate(date);
    return plan?.template_id ? templates.find((t) => t.id === plan.template_id) : null;
  };

  const currentTemplate = getTemplateForDate(selectedDate);

  // Week view: 7 days from Monday
  const weekStart = startOfWeek(selectedDate, { weekStartsOn: 1 });
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 md:py-10 space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl md:text-3xl font-display font-bold text-foreground">Planner 📆</h1>
        <Button variant="outline" onClick={() => setShowTemplates(!showTemplates)} className="rounded-2xl font-body font-semibold text-sm gap-2">
          <Settings2 className="w-4 h-4" /> Templates
          <ChevronDown className={`w-3.5 h-3.5 transition-transform ${showTemplates ? "rotate-180" : ""}`} />
        </Button>
      </div>

      {/* Templates panel */}
      <AnimatePresence>
        {showTemplates && (
          <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
            className="bg-card rounded-3xl border border-border p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-display font-bold text-base">Schedule Templates</h2>
              <Button size="sm" onClick={() => { setEditingTemplate(null); setShowTemplateForm(true); }} className="rounded-2xl font-body text-xs">
                <Plus className="w-3.5 h-3.5 mr-1" /> New
              </Button>
            </div>

            <AnimatePresence>
              {showTemplateForm && (
                <TemplateForm
                  template={editingTemplate}
                  habits={habits}
                  reminders={reminders}
                  onSubmit={(data) => createTemplate.mutate(data)}
                  onCancel={() => { setShowTemplateForm(false); setEditingTemplate(null); }}
                />
              )}
            </AnimatePresence>

            {templates.length === 0 && !showTemplateForm ? (
              <p className="text-sm text-muted-foreground font-body text-center py-4">
                Create your first template (e.g. "Class A Day", "Work From Home")
              </p>
            ) : (
              <div className="space-y-2">
                {templates.map((t) => (
                  <div key={t.id} className="flex items-center gap-3 p-3 rounded-2xl border border-border bg-muted/30">
                    <span className="text-xl">{t.emoji}</span>
                    <div className="flex-1 min-w-0">
                      <p className="font-display font-semibold text-sm truncate">{t.name}</p>
                      <p className="text-xs text-muted-foreground font-body">{(t.time_blocks || []).length} blocks</p>
                    </div>
                    <div className="flex gap-1">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: t.color }} />
                      <Button variant="ghost" size="icon" className="h-7 w-7 rounded-lg" onClick={() => { setEditingTemplate(t); setShowTemplateForm(true); }}>
                        <Pencil className="w-3 h-3" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7 rounded-lg text-destructive" onClick={() => deleteTemplate.mutate(t.id)}>
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* View switcher */}
      <div className="flex bg-muted rounded-2xl p-1 gap-1">
        {VIEWS.map((v) => (
          <button key={v.key} onClick={() => setView(v.key)}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-sm font-body font-semibold transition-all ${view === v.key ? "bg-card shadow text-foreground" : "text-muted-foreground"}`}>
            <v.icon className="w-4 h-4" /> {v.label}
          </button>
        ))}
      </div>

      {/* Calendar */}
      <MiniCalendar
        currentMonth={currentMonth}
        selectedDate={selectedDate}
        onSelectDate={setSelectedDate}
        onPrevMonth={() => setCurrentMonth(subMonths(currentMonth, 1))}
        onNextMonth={() => setCurrentMonth(addMonths(currentMonth, 1))}
        dayPlans={dayPlans}
        templates={templates}
      />

      {/* Week view — quick template assign for each day */}
      {view === "week" && (
        <div className="bg-card rounded-3xl border border-border p-5">
          <h2 className="font-display font-bold text-base mb-4">Week at a Glance</h2>
          <div className="space-y-2">
            {weekDays.map((day) => {
              const tmpl = getTemplateForDate(day);
              const dateStr = format(day, "yyyy-MM-dd");
              const isToday = dateStr === format(new Date(), "yyyy-MM-dd");
              return (
                <div key={dateStr} className="flex items-center gap-3 p-3 rounded-2xl border border-border">
                  <div className={`w-10 text-center flex-shrink-0 ${isToday ? "text-primary" : ""}`}>
                    <p className="text-xs font-body font-bold text-muted-foreground">{format(day, "EEE")}</p>
                    <p className={`text-base font-display font-bold ${isToday ? "text-primary" : "text-foreground"}`}>{format(day, "d")}</p>
                  </div>
                  <div className="flex-1 min-w-0">
                    {tmpl ? (
                      <div className="flex items-center gap-2">
                        <span>{tmpl.emoji}</span>
                        <span className="text-sm font-display font-semibold truncate">{tmpl.name}</span>
                        <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: tmpl.color }} />
                      </div>
                    ) : (
                      <span className="text-sm text-muted-foreground font-body">No template</span>
                    )}
                  </div>
                  <div className="flex gap-1">
                    {templates.slice(0, 3).map((t) => (
                      <button key={t.id} onClick={() => upsertPlan.mutate({ date: dateStr, templateId: t.id, templateName: t.name })}
                        className={`w-7 h-7 rounded-lg text-sm flex items-center justify-center border-2 transition-all ${tmpl?.id === t.id ? "border-primary bg-primary/10" : "border-border bg-muted"}`}
                        title={t.name}>
                        {t.emoji}
                      </button>
                    ))}
                    {tmpl && (
                      <button onClick={() => clearPlan.mutate(dateStr)} className="w-7 h-7 rounded-lg flex items-center justify-center text-muted-foreground hover:text-destructive border border-border bg-muted" title="Clear">
                        ×
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Day view — template picker + timeline */}
      {(view === "day" || view === "month") && (
        <div className="bg-card rounded-3xl border border-border p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-display font-bold text-base">{format(selectedDate, "EEEE, MMM d")}</h2>
              {currentTemplate && (
                <p className="text-xs text-muted-foreground font-body mt-0.5">
                  {currentTemplate.emoji} {currentTemplate.name}
                </p>
              )}
            </div>
            {currentTemplate && (
              <Button variant="ghost" size="sm" onClick={() => clearPlan.mutate(selectedDateStr)} className="rounded-xl text-xs text-muted-foreground">
                Clear
              </Button>
            )}
          </div>

          {/* Template picker */}
          {templates.length > 0 && (
            <div>
              <p className="text-xs font-body font-semibold text-muted-foreground mb-2">Apply a schedule template:</p>
              <div className="flex flex-wrap gap-2">
                {templates.map((t) => {
                  const isActive = currentTemplate?.id === t.id;
                  return (
                    <motion.button
                      key={t.id}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => isActive ? clearPlan.mutate(selectedDateStr) : upsertPlan.mutate({ date: selectedDateStr, templateId: t.id, templateName: t.name })}
                      className={`flex items-center gap-2 px-3 py-2 rounded-2xl border-2 text-sm font-body font-semibold transition-all ${
                        isActive ? "border-primary bg-primary/5 text-primary" : "border-border bg-muted hover:border-primary/40"
                      }`}
                    >
                      <span>{t.emoji}</span>
                      <span>{t.name}</span>
                      {isActive && <Check className="w-3.5 h-3.5" />}
                    </motion.button>
                  );
                })}
              </div>
            </div>
          )}

          {templates.length === 0 && (
            <p className="text-sm text-muted-foreground font-body text-center py-4">
              Create a schedule template above to start planning your day.
            </p>
          )}

          {/* Timeline */}
          {currentTemplate && currentTemplate.time_blocks?.length > 0 && (
            <div>
              <p className="text-xs font-body font-semibold text-muted-foreground mb-3 uppercase tracking-wider">Timeline</p>
              <DayTimeline blocks={currentTemplate.time_blocks} habits={habits} reminders={reminders} date={selectedDateStr} logs={logs} onAddProof={handleAddProof} />
            </div>
          )}
        </div>
      )}
    </div>
  );
}