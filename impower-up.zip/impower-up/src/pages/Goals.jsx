import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AnimatePresence } from "framer-motion";
import GoalForm from "@/components/goals/GoalForm";
import GoalCard from "@/components/goals/GoalCard";

export default function Goals() {
  const [showForm, setShowForm] = useState(false);
  const [editingGoal, setEditingGoal] = useState(null);
  const queryClient = useQueryClient();

  const { data: goals = [] } = useQuery({
    queryKey: ["goals-all"],
    queryFn: () => base44.entities.Goal.list("-created_date"),
  });

  const { data: reminders = [] } = useQuery({
    queryKey: ["reminders"],
    queryFn: () => base44.entities.Reminder.list(),
  });

  const createGoal = useMutation({
    mutationFn: ({ alarm, ...goalData }) => base44.entities.Goal.create(goalData),
    onSuccess: async (createdGoal, variables) => {
      queryClient.invalidateQueries({ queryKey: ["goals-all"] });
      queryClient.invalidateQueries({ queryKey: ["goals"] });
      if (variables.alarm?.enabled) {
        await base44.entities.Reminder.create({
          title: createdGoal.title,
          goal_id: createdGoal.id,
          time: variables.alarm.time,
          days: variables.alarm.days,
          alarm_level: variables.alarm.alarm_level,
          snooze_allowed: variables.alarm.snooze_allowed,
          max_snoozes: variables.alarm.max_snoozes,
          message: variables.alarm.message,
          is_active: true,
        });
        queryClient.invalidateQueries({ queryKey: ["reminders"] });
      }
      setShowForm(false);
    },
  });

  const updateGoal = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Goal.update(id, data),
    onSuccess: async (updatedGoal, { alarm, linkedReminderId }) => {
      queryClient.invalidateQueries({ queryKey: ["goals-all"] });
      queryClient.invalidateQueries({ queryKey: ["goals"] });
      const reminderData = alarm?.enabled
        ? {
            title: updatedGoal.title,
            goal_id: updatedGoal.id,
            time: alarm.time,
            days: alarm.days,
            alarm_level: alarm.alarm_level,
            snooze_allowed: alarm.snooze_allowed,
            max_snoozes: alarm.max_snoozes,
            message: alarm.message,
            is_active: true,
          }
        : null;
      if (reminderData) {
        if (linkedReminderId) {
          await base44.entities.Reminder.update(linkedReminderId, reminderData);
        } else {
          await base44.entities.Reminder.create(reminderData);
        }
      } else if (linkedReminderId) {
        await base44.entities.Reminder.delete(linkedReminderId);
      }
      queryClient.invalidateQueries({ queryKey: ["reminders"] });
      setEditingGoal(null);
      setShowForm(false);
    },
  });

  const deleteGoal = useMutation({
    mutationFn: (id) => base44.entities.Goal.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["goals-all"] });
      queryClient.invalidateQueries({ queryKey: ["goals"] });
    },
  });

  const handleSubmit = (data) => {
    const { alarm, ...goalData } = data;
    if (editingGoal) {
      const linkedReminder = reminders.find((r) => r.goal_id === editingGoal.id);
      updateGoal.mutate({ id: editingGoal.id, data: goalData, alarm, linkedReminderId: linkedReminder?.id });
    } else {
      createGoal.mutate({ ...goalData, alarm });
    }
  };

  const toggleMilestone = (goal, index) => {
    const milestones = [...goal.milestones];
    milestones[index] = { ...milestones[index], completed: !milestones[index].completed };
    const progress = Math.round((milestones.filter((m) => m.completed).length / milestones.length) * 100);
    const status = progress === 100 ? "completed" : "active";
    updateGoal.mutate({ id: goal.id, data: { milestones, progress, status } });
  };

  const activeGoals = goals.filter((g) => g.status !== "completed");
  const completedGoals = goals.filter((g) => g.status === "completed");

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 md:py-10 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl md:text-3xl font-display font-bold text-foreground">Goals 🎯</h1>
        <Button onClick={() => { setEditingGoal(null); setShowForm(true); }} className="rounded-2xl font-body font-semibold bg-secondary hover:bg-secondary/90">
          <Plus className="w-4 h-4 mr-2" /> New Goal
        </Button>
      </div>

      <AnimatePresence>
        {showForm && (
          <GoalForm goal={editingGoal} linkedReminder={reminders.find((r) => r.goal_id === editingGoal?.id)} onSubmit={handleSubmit} onCancel={() => { setShowForm(false); setEditingGoal(null); }} />
        )}
      </AnimatePresence>

      {goals.length === 0 && !showForm ? (
        <div className="text-center py-16 bg-card rounded-3xl border-2 border-dashed border-border">
          <p className="text-5xl mb-4">🚀</p>
          <p className="font-display font-bold text-xl text-foreground mb-2">Set your first goal!</p>
          <p className="text-sm text-muted-foreground font-body mb-6 max-w-xs mx-auto">
            Break big dreams into small milestones you can actually track.
          </p>
          <Button onClick={() => setShowForm(true)} className="rounded-2xl font-body font-semibold bg-secondary hover:bg-secondary/90">
            <Plus className="w-4 h-4 mr-2" /> Create Goal
          </Button>
        </div>
      ) : (
        <div className="space-y-6">
          {activeGoals.length > 0 && (
            <div className="space-y-3">
              <h2 className="font-display font-bold text-sm text-muted-foreground uppercase tracking-wider">Active</h2>
              {activeGoals.map((goal) => (
                <GoalCard
                  key={goal.id}
                  goal={goal}
                  onToggleMilestone={toggleMilestone}
                  onEdit={(g) => { setEditingGoal(g); setShowForm(true); }}
                  onDelete={(id) => deleteGoal.mutate(id)}
                />
              ))}
            </div>
          )}

          {completedGoals.length > 0 && (
            <div className="space-y-3">
              <h2 className="font-display font-bold text-sm text-muted-foreground uppercase tracking-wider">Completed 🎉</h2>
              {completedGoals.map((goal) => (
                <GoalCard
                  key={goal.id}
                  goal={goal}
                  onToggleMilestone={toggleMilestone}
                  onEdit={(g) => { setEditingGoal(g); setShowForm(true); }}
                  onDelete={(id) => deleteGoal.mutate(id)}
                />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}