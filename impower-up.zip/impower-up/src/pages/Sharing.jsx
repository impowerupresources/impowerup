import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Copy, Trash2, Check, UserCheck, Bell, BellOff, Mail, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";

const RELATIONSHIPS = [
  { value: "therapist", label: "Therapist" },
  { value: "mentor", label: "Mentor" },
  { value: "parent", label: "Parent/Guardian" },
  { value: "coach", label: "Coach" },
  { value: "teacher", label: "Teacher" },
  { value: "other", label: "Other" },
];

const SHARE_OPTIONS = [
  { value: "habits", label: "Habit streaks & completions" },
  { value: "goals", label: "Goals & milestones" },
  { value: "points", label: "XP points & level" },
  { value: "streaks", label: "Daily streaks" },
  { value: "proofs", label: "Proof photos" },
];

const NOTIFY_METHODS = [
  { value: "email", label: "Email", icon: Mail },
  { value: "sms", label: "Text Message", icon: MessageSquare },
  { value: "both", label: "Email + Text", icon: Bell },
];

const emptyForm = {
  mentor_name: "",
  mentor_email: "",
  mentor_phone: "",
  relationship: "mentor",
  shared_data: ["habits", "goals", "points", "streaks", "proofs"],
  notify_on_completion: false,
  notify_method: "email",
};

export default function Sharing() {
  const [showForm, setShowForm] = useState(false);
  const [copied, setCopied] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const queryClient = useQueryClient();

  const { data: links = [] } = useQuery({
    queryKey: ["share-links"],
    queryFn: () => base44.entities.ShareLink.list("-created_date"),
  });

  const createLink = useMutation({
    mutationFn: (data) => {
      const code = Math.random().toString(36).substring(2, 10).toUpperCase();
      return base44.entities.ShareLink.create({ ...data, share_code: code });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["share-links"] });
      setShowForm(false);
      setForm(emptyForm);
      toast.success("Share link created!");
    },
  });

  const updateLink = useMutation({
    mutationFn: ({ id, data }) => base44.entities.ShareLink.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["share-links"] }),
  });

  const deleteLink = useMutation({
    mutationFn: (id) => base44.entities.ShareLink.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["share-links"] }),
  });

  const toggleSharedData = (value) => {
    setForm({
      ...form,
      shared_data: form.shared_data.includes(value)
        ? form.shared_data.filter((d) => d !== value)
        : [...form.shared_data, value],
    });
  };

  const copyLink = (code) => {
    navigator.clipboard.writeText(`${window.location.origin}/shared/${code}`);
    setCopied(code);
    toast.success("Link copied!");
    setTimeout(() => setCopied(null), 2000);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.mentor_name.trim()) return;
    createLink.mutate(form);
  };

  const toggleNotify = (link) => {
    updateLink.mutate(
      { id: link.id, data: { notify_on_completion: !link.notify_on_completion } },
      {
        onSuccess: () =>
          toast.success(
            link.notify_on_completion ? "Notifications turned off" : "Notifications turned on"
          ),
      }
    );
  };

  const needsPhone = form.notify_on_completion && (form.notify_method === "sms" || form.notify_method === "both");

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 md:py-10 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl md:text-3xl font-display font-bold text-foreground">Sharing 🤝</h1>
        <Button onClick={() => setShowForm(true)} className="rounded-2xl font-body font-semibold">
          <Plus className="w-4 h-4 mr-2" /> Add Mentor
        </Button>
      </div>

      <div className="bg-secondary/5 border border-secondary/20 rounded-3xl p-5">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-2xl bg-secondary/10 flex items-center justify-center flex-shrink-0">
            <UserCheck className="w-5 h-5 text-secondary" />
          </div>
          <div>
            <h3 className="font-display font-bold text-sm text-foreground">Accountability Partners</h3>
            <p className="text-xs text-muted-foreground font-body mt-1">
              Share your progress with therapists, mentors, or anyone who helps keep you on track.
              Enable auto-notifications so they know the moment you complete a task.
            </p>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="bg-card rounded-3xl border border-border p-6 shadow-lg"
          >
            <h3 className="font-display font-bold text-lg mb-5">Add Accountability Partner</h3>
            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <Label className="font-body font-semibold text-sm">Name</Label>
                <Input value={form.mentor_name} onChange={(e) => setForm({ ...form, mentor_name: e.target.value })} placeholder="Dr. Smith" className="mt-1 rounded-xl" />
              </div>

              <div>
                <Label className="font-body font-semibold text-sm">Email (for notifications)</Label>
                <Input value={form.mentor_email} onChange={(e) => setForm({ ...form, mentor_email: e.target.value })} placeholder="therapist@email.com" className="mt-1 rounded-xl" />
              </div>

              <div>
                <Label className="font-body font-semibold text-sm">Relationship</Label>
                <Select value={form.relationship} onValueChange={(v) => setForm({ ...form, relationship: v })}>
                  <SelectTrigger className="mt-1 rounded-xl"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {RELATIONSHIPS.map((r) => <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="font-body font-semibold text-sm mb-3 block">What to share</Label>
                <div className="space-y-3">
                  {SHARE_OPTIONS.map((opt) => (
                    <label key={opt.value} className="flex items-center gap-3 cursor-pointer">
                      <Checkbox
                        checked={form.shared_data.includes(opt.value)}
                        onCheckedChange={() => toggleSharedData(opt.value)}
                        className="rounded-md"
                      />
                      <span className="text-sm font-body">{opt.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Auto-notification settings */}
              <div className="bg-muted/50 rounded-2xl p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-body font-semibold text-sm flex items-center gap-2">
                      <Bell className="w-4 h-4 text-primary" />
                      Auto-notify on completion
                    </p>
                    <p className="text-xs text-muted-foreground font-body mt-0.5">
                      Send a message when you complete a task
                    </p>
                  </div>
                  <Switch
                    checked={form.notify_on_completion}
                    onCheckedChange={(v) => setForm({ ...form, notify_on_completion: v })}
                  />
                </div>

                {form.notify_on_completion && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    className="space-y-3 pt-1"
                  >
                    <div>
                      <Label className="font-body font-semibold text-sm mb-2 block">Notification method</Label>
                      <div className="grid grid-cols-3 gap-2">
                        {NOTIFY_METHODS.map((method) => {
                          const Icon = method.icon;
                          const active = form.notify_method === method.value;
                          return (
                            <button
                              key={method.value}
                              type="button"
                              onClick={() => setForm({ ...form, notify_method: method.value })}
                              className={`flex flex-col items-center gap-1 py-3 rounded-xl border-2 transition-all text-xs font-body font-semibold ${
                                active ? "border-primary bg-primary/5 text-primary" : "border-border text-muted-foreground"
                              }`}
                            >
                              <Icon className="w-4 h-4" />
                              {method.label}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {needsPhone && (
                      <div>
                        <Label className="font-body font-semibold text-sm">Phone number</Label>
                        <Input
                          value={form.mentor_phone}
                          onChange={(e) => setForm({ ...form, mentor_phone: e.target.value })}
                          placeholder="555-123-4567"
                          className="mt-1 rounded-xl"
                        />
                        <p className="text-xs text-muted-foreground font-body mt-1">
                          Text messages require a messaging service — email notifications work now.
                        </p>
                      </div>
                    )}
                  </motion.div>
                )}
              </div>

              <div className="flex gap-3 pt-2">
                <Button type="button" variant="outline" onClick={() => setShowForm(false)} className="flex-1 rounded-2xl font-body font-semibold">Cancel</Button>
                <Button type="submit" className="flex-1 rounded-2xl font-body font-semibold">Create Share Link</Button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {links.length === 0 && !showForm ? (
        <div className="text-center py-16 bg-card rounded-3xl border-2 border-dashed border-border">
          <p className="text-5xl mb-4">🤝</p>
          <p className="font-display font-bold text-xl text-foreground mb-2">No one added yet</p>
          <p className="text-sm text-muted-foreground font-body mb-6 max-w-xs mx-auto">
            Add a mentor, therapist, or parent to share your progress with.
          </p>
          <Button onClick={() => setShowForm(true)} className="rounded-2xl font-body font-semibold">
            <Plus className="w-4 h-4 mr-2" /> Add Mentor
          </Button>
        </div>
      ) : (
        <div className="space-y-3">
          {links.map((link, i) => (
            <motion.div
              key={link.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="bg-card rounded-2xl border border-border p-4"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <UserCheck className="w-5 h-5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-display font-semibold text-foreground">{link.mentor_name}</p>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    <Badge variant="secondary" className="rounded-lg text-xs font-body capitalize">{link.relationship}</Badge>
                    <span className="text-xs text-muted-foreground font-body">
                      {(link.shared_data || []).length} items shared
                    </span>
                    {link.notify_on_completion && (
                      <Badge className="rounded-lg text-xs font-body bg-primary/10 text-primary border-0">
                        <Bell className="w-3 h-3 mr-1" /> Auto-notify
                      </Badge>
                    )}
                  </div>
                </div>
                <div className="flex gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className={`rounded-xl h-8 w-8 ${link.notify_on_completion ? "text-primary" : "text-muted-foreground"}`}
                    onClick={() => toggleNotify(link)}
                    title={link.notify_on_completion ? "Notifications on" : "Notifications off"}
                  >
                    {link.notify_on_completion ? <Bell className="w-3.5 h-3.5" /> : <BellOff className="w-3.5 h-3.5" />}
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="rounded-xl h-8 w-8"
                    onClick={() => copyLink(link.share_code)}
                  >
                    {copied === link.share_code ? <Check className="w-3.5 h-3.5 text-chart-5" /> : <Copy className="w-3.5 h-3.5" />}
                  </Button>
                  <Button variant="ghost" size="icon" className="rounded-xl h-8 w-8 text-destructive" onClick={() => deleteLink.mutate(link.id)}>
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}