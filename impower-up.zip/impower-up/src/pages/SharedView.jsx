import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Trophy, Flame, Target, Sparkles, Calendar, Camera } from "lucide-react";
import { format } from "date-fns";
import { motion } from "framer-motion";
import ProofPhotoGallery from "@/components/shared/ProofPhotoGallery";

export default function SharedView() {
  const urlParams = new URLSearchParams(window.location.search);
  const code = window.location.pathname.split("/shared/")[1] || urlParams.get("code");

  const { data: links = [], isLoading: linksLoading } = useQuery({
    queryKey: ["share-link", code],
    queryFn: () => base44.entities.ShareLink.filter({ share_code: code, is_active: true }),
    enabled: !!code,
  });

  const link = links[0];
  const sharedData = link?.shared_data || [];
  const userId = link?.created_by_id;

  const { data: habits = [] } = useQuery({
    queryKey: ["shared-habits", userId],
    queryFn: () => base44.entities.Habit.filter({ created_by_id: userId, is_active: true }),
    enabled: !!userId && (sharedData.includes("habits") || sharedData.includes("proofs")),
  });

  const { data: goals = [] } = useQuery({
    queryKey: ["shared-goals", userId],
    queryFn: () => base44.entities.Goal.filter({ created_by_id: userId }),
    enabled: !!userId && sharedData.includes("goals"),
  });

  const { data: logs = [] } = useQuery({
    queryKey: ["shared-logs", userId],
    queryFn: () => base44.entities.HabitLog.filter({ created_by_id: userId }),
    enabled: !!userId && (sharedData.includes("points") || sharedData.includes("proofs")),
  });

  if (linksLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!link) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background px-4">
        <div className="text-center">
          <p className="text-5xl mb-4">🔒</p>
          <h1 className="font-display font-bold text-2xl text-foreground mb-2">Link not found</h1>
          <p className="text-muted-foreground font-body">This share link may have been deactivated or doesn't exist.</p>
        </div>
      </div>
    );
  }

  const totalPoints = logs.reduce((sum, l) => sum + (l.points_earned || 0), 0);
  const bestStreak = Math.max(0, ...habits.map((h) => h.best_streak || 0));

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-2xl mx-auto px-4 py-8 space-y-6">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="bg-gradient-to-br from-primary via-primary/90 to-secondary rounded-3xl p-6 text-primary-foreground">
            <p className="text-sm font-body opacity-80">Progress shared with</p>
            <h1 className="font-display font-bold text-2xl mt-1">{link.mentor_name}</h1>
            <p className="text-sm font-body opacity-70 capitalize mt-1">{link.relationship}</p>
          </div>
        </motion.div>

        {sharedData.includes("points") && (
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-card rounded-2xl border border-border p-4">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mb-3">
                <Trophy className="w-5 h-5 text-primary" />
              </div>
              <p className="text-2xl font-display font-bold">{totalPoints}</p>
              <p className="text-xs text-muted-foreground font-body">Total XP</p>
            </div>
            <div className="bg-card rounded-2xl border border-border p-4">
              <div className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center mb-3">
                <Flame className="w-5 h-5 text-accent-foreground" />
              </div>
              <p className="text-2xl font-display font-bold">{bestStreak}</p>
              <p className="text-xs text-muted-foreground font-body">Best Streak</p>
            </div>
          </div>
        )}

        {sharedData.includes("habits") && habits.length > 0 && (
          <div>
            <h2 className="font-display font-bold text-lg mb-3 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-primary" /> Habits
            </h2>
            <div className="space-y-2">
              {habits.map((h) => (
                <div key={h.id} className="bg-card rounded-2xl border border-border p-4 flex items-center gap-4">
                  <span className="text-2xl">{h.emoji}</span>
                  <div className="flex-1">
                    <p className="font-display font-semibold">{h.title}</p>
                    <p className="text-xs text-muted-foreground font-body">
                      Streak: {h.current_streak || 0} days · {h.total_completions || 0} total
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {sharedData.includes("goals") && goals.length > 0 && (
          <div>
            <h2 className="font-display font-bold text-lg mb-3 flex items-center gap-2">
              <Target className="w-5 h-5 text-secondary" /> Goals
            </h2>
            <div className="space-y-2">
              {goals.map((g) => {
                const completed = (g.milestones || []).filter((m) => m.completed).length;
                const total = (g.milestones || []).length;
                const progress = total > 0 ? Math.round((completed / total) * 100) : g.progress || 0;
                return (
                  <div key={g.id} className="bg-card rounded-2xl border border-border p-4">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-2xl">{g.emoji || "🎯"}</span>
                      <div>
                        <p className="font-display font-semibold">{g.title}</p>
                        {g.target_date && (
                          <p className="text-xs text-muted-foreground font-body flex items-center gap-1">
                            <Calendar className="w-3 h-3" /> {format(new Date(g.target_date), "MMM d, yyyy")}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-secondary to-primary rounded-full" style={{ width: `${progress}%` }} />
                    </div>
                    <p className="text-xs text-muted-foreground font-body mt-1">{progress}% complete</p>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {sharedData.includes("proofs") && (
          <div>
            <h2 className="font-display font-bold text-lg mb-3 flex items-center gap-2">
              <Camera className="w-5 h-5 text-primary" /> Proof Photos
            </h2>
            <ProofPhotoGallery logs={logs} habits={habits} />
          </div>
        )}
      </div>
    </div>
  );
}