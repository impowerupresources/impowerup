import React, { useMemo, useRef, useState, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { Plus, Sparkles, RefreshCw } from "lucide-react";
import { Link } from "react-router-dom";
import { motion, useMotionValue, useTransform, animate } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/AuthContext";
import PointsBanner from "@/components/dashboard/PointsBanner";
import QuickStats from "@/components/dashboard/QuickStats";
import HabitCheckCard from "@/components/dashboard/HabitCheckCard";
import { toast } from "@/components/ui/use-toast";

const today = () => format(new Date(), "yyyy-MM-dd");

export default function Home() {
  const queryClient = useQueryClient();
  const todayStr = today();
  const { user } = useAuth();
  const displayName = user?.nickname || user?.first_name || "friend";

  // Pull-to-refresh state
  const pullY = useMotionValue(0);
  const pullOpacity = useTransform(pullY, [0, 60], [0, 1]);
  const pullRotate = useTransform(pullY, [0, 80], [0, 180]);
  const [refreshing, setRefreshing] = useState(false);
  const touchStartY = useRef(0);
  const containerRef = useRef(null);

  const handleTouchStart = (e) => {
    touchStartY.current = e.touches[0].clientY;
  };

  const handleTouchMove = (e) => {
    const scrollTop = containerRef.current?.scrollTop ?? 0;
    if (scrollTop > 0) return;
    const delta = Math.max(0, e.touches[0].clientY - touchStartY.current);
    pullY.set(Math.min(delta * 0.4, 80));
  };

  const handleTouchEnd = async () => {
    if (pullY.get() > 50 && !refreshing) {
      setRefreshing(true);
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["habits"] }),
        queryClient.invalidateQueries({ queryKey: ["habit-logs"] }),
        queryClient.invalidateQueries({ queryKey: ["goals"] }),
      ]);
      setRefreshing(false);
    }
    animate(pullY, 0, { duration: 0.3 });
  };

  const { data: habits = [] } = useQuery({
    queryKey: ["habits"],
    queryFn: () => base44.entities.Habit.filter({ is_active: true }),
  });

  const { data: logs = [] } = useQuery({
    queryKey: ["habit-logs"],
    queryFn: () => base44.entities.HabitLog.list("-completed_date", 500),
  });

  const { data: goals = [] } = useQuery({
    queryKey: ["goals"],
    queryFn: () => base44.entities.Goal.filter({ status: "active" }),
  });

  const { data: shareLinks = [] } = useQuery({
    queryKey: ["share-links"],
    queryFn: () => base44.entities.ShareLink.filter({ is_active: true }),
  });

  const todayLogs = useMemo(() => logs.filter((l) => l.completed_date === todayStr), [logs, todayStr]);
  const completedIds = useMemo(() => new Set(todayLogs.map((l) => l.habit_id)), [todayLogs]);

  const proofMap = useMemo(() => {
    const map = {};
    todayLogs.forEach((l) => {
      if (l.proof_photo_url) map[l.habit_id] = l.proof_photo_url;
    });
    return map;
  }, [todayLogs]);

  const totalPoints = useMemo(() => logs.reduce((sum, l) => sum + (l.points_earned || 0), 0), [logs]);
  const bestStreak = useMemo(() => Math.max(0, ...habits.map((h) => h.best_streak || 0)), [habits]);

  const weekAgo = useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() - 7);
    return format(d, "yyyy-MM-dd");
  }, []);
  const weeklyCompletions = useMemo(() => logs.filter((l) => l.completed_date >= weekAgo).length, [logs, weekAgo]);
  const completionRate = habits.length > 0 ? Math.round((todayLogs.length / habits.length) * 100) : 0;

  const currentStreak = useMemo(() => {
    if (habits.length === 0) return 0;
    let streak = 0;
    const d = new Date();
    for (let i = 0; i < 365; i++) {
      const dateStr = format(d, "yyyy-MM-dd");
      const dayLogs = logs.filter((l) => l.completed_date === dateStr);
      if (dayLogs.length > 0) {
        streak++;
        d.setDate(d.getDate() - 1);
      } else {
        break;
      }
    }
    return streak;
  }, [logs, habits]);

  const notifyMentors = async (habit) => {
    const notifiable = shareLinks.filter((l) => l.notify_on_completion);
    if (notifiable.length === 0) return;
    const userName = user?.nickname || user?.first_name || "your client";
    for (const link of notifiable) {
      try {
        if ((link.notify_method === "email" || link.notify_method === "both") && link.mentor_email) {
          await base44.integrations.Core.SendEmail({
            to: link.mentor_email,
            subject: `Task Completed: ${habit.title} 🎉`,
            body: `Hi ${link.mentor_name},\n\n${userName} just completed "${habit.title}" today.\n\nKeep up the great work! 💪`,
          });
        }
        toast({
          title: `📨 ${link.mentor_name} notified`,
          description: `Your ${link.relationship} was notified about "${habit.title}".`,
        });
      } catch (err) {
        // Notification failed — don't block completion
      }
    }
  };

  const handleAddProof = async (habit, file) => {
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const existing = todayLogs.find((l) => l.habit_id === habit.id);
      let isNew = false;
      if (existing) {
        await base44.entities.HabitLog.update(existing.id, { proof_photo_url: file_url });
      } else {
        isNew = true;
        await base44.entities.HabitLog.create({
          habit_id: habit.id,
          completed_date: todayStr,
          points_earned: habit.points_per_completion || 10,
          proof_photo_url: file_url,
        });
        const newStreak = (habit.current_streak || 0) + 1;
        await base44.entities.Habit.update(habit.id, {
          current_streak: newStreak,
          best_streak: Math.max(newStreak, habit.best_streak || 0),
          total_completions: (habit.total_completions || 0) + 1,
        });
        await notifyMentors(habit);
      }
      queryClient.invalidateQueries({ queryKey: ["habit-logs"] });
      queryClient.invalidateQueries({ queryKey: ["habits"] });
      return isNew;
    } catch (err) {
      toast({ title: "Upload failed", description: err.message, variant: "destructive" });
      return false;
    }
  };

  const toggleLog = useMutation({
    mutationFn: async (habit) => {
      const existing = todayLogs.find((l) => l.habit_id === habit.id);
      if (existing) {
        await base44.entities.HabitLog.delete(existing.id);
        await base44.entities.Habit.update(habit.id, {
          current_streak: Math.max(0, (habit.current_streak || 0) - 1),
          total_completions: Math.max(0, (habit.total_completions || 0) - 1),
        });
        return { completed: false, habit };
      } else {
        await base44.entities.HabitLog.create({
          habit_id: habit.id,
          completed_date: todayStr,
          points_earned: habit.points_per_completion || 10,
        });
        const newStreak = (habit.current_streak || 0) + 1;
        await base44.entities.Habit.update(habit.id, {
          current_streak: newStreak,
          best_streak: Math.max(newStreak, habit.best_streak || 0),
          total_completions: (habit.total_completions || 0) + 1,
        });
        return { completed: true, habit };
      }
    },
    onSuccess: (result) => {
      if (result?.completed) {
        notifyMentors(result.habit);
      }
    },
    onMutate: async (habit) => {
      // Cancel in-flight refetches
      await queryClient.cancelQueries({ queryKey: ["habit-logs"] });
      const prevLogs = queryClient.getQueryData(["habit-logs"]);
      const isCompleted = prevLogs?.some((l) => l.habit_id === habit.id && l.completed_date === todayStr);

      queryClient.setQueryData(["habit-logs"], (old = []) => {
        if (isCompleted) {
          return old.filter((l) => !(l.habit_id === habit.id && l.completed_date === todayStr));
        }
        return [...old, { id: `optimistic-${habit.id}`, habit_id: habit.id, completed_date: todayStr, points_earned: habit.points_per_completion || 10 }];
      });
      return { prevLogs };
    },
    onError: (_err, _habit, context) => {
      if (context?.prevLogs) queryClient.setQueryData(["habit-logs"], context.prevLogs);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["habits"] });
      queryClient.invalidateQueries({ queryKey: ["habit-logs"] });
    },
  });

  return (
    <div
      ref={containerRef}
      className="max-w-2xl mx-auto px-4 py-6 md:py-10 space-y-6"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Pull-to-refresh indicator */}
      <motion.div
        style={{ height: pullY, opacity: pullOpacity }}
        className="flex items-center justify-center overflow-hidden -mt-6"
      >
        <motion.div style={{ rotate: refreshing ? 360 : pullRotate }}>
          <RefreshCw className={`w-5 h-5 text-primary ${refreshing ? "animate-spin" : ""}`} />
        </motion.div>
      </motion.div>
      <div className="flex items-center justify-between">
        <div>
          <motion.h1
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="text-2xl md:text-3xl font-display font-bold text-foreground"
          >
            Hey there, {displayName}! 👋
          </motion.h1>
          <p className="text-muted-foreground font-body text-sm mt-1">
            {format(new Date(), "EEEE, MMMM d")}
          </p>
        </div>
      </div>

      <PointsBanner
        totalPoints={totalPoints}
        currentStreak={currentStreak}
        habitsToday={todayLogs.length}
        habitsTotal={habits.length}
      />

      <QuickStats
        weeklyCompletions={weeklyCompletions}
        activeGoals={goals.length}
        bestStreak={bestStreak}
        completionRate={completionRate}
      />

      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display font-bold text-lg text-foreground flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            Today's Habits
          </h2>
          <Link to="/habits">
            <Button variant="ghost" size="sm" className="rounded-xl text-primary font-body font-semibold">
              <Plus className="w-4 h-4 mr-1" /> Add
            </Button>
          </Link>
        </div>

        {habits.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12 bg-card rounded-3xl border-2 border-dashed border-border"
          >
            <p className="text-4xl mb-3">🌱</p>
            <p className="font-display font-bold text-foreground mb-1">No habits yet!</p>
            <p className="text-sm text-muted-foreground font-body mb-4">Start by adding your first habit</p>
            <Link to="/habits">
              <Button className="rounded-2xl font-body font-semibold">
                <Plus className="w-4 h-4 mr-2" /> Create First Habit
              </Button>
            </Link>
          </motion.div>
        ) : (
          <div className="space-y-3">
            {habits.map((habit, i) => (
              <motion.div
                key={habit.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <HabitCheckCard
                  habit={habit}
                  isCompleted={completedIds.has(habit.id)}
                  proofPhotoUrl={proofMap[habit.id]}
                  onToggle={() => toggleLog.mutate(habit)}
                  onAddProof={(file) => handleAddProof(habit, file)}
                />
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}