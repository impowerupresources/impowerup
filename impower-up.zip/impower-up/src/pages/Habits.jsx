import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Pencil, Trash2, Flame } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import HabitForm from "@/components/habits/HabitForm";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function Habits() {
  const [showForm, setShowForm] = useState(false);
  const [editingHabit, setEditingHabit] = useState(null);
  const queryClient = useQueryClient();

  const { data: habits = [] } = useQuery({
    queryKey: ["habits-all"],
    queryFn: () => base44.entities.Habit.list("-created_date"),
  });

  const { data: reminders = [] } = useQuery({
    queryKey: ["reminders"],
    queryFn: () => base44.entities.Reminder.list(),
  });

  const createHabit = useMutation({
    mutationFn: ({ alarm, ...habitData }) => base44.entities.Habit.create(habitData),
    onSuccess: async (createdHabit, variables) => {
      queryClient.invalidateQueries({ queryKey: ["habits-all"] });
      queryClient.invalidateQueries({ queryKey: ["habits"] });
      if (variables.alarm?.enabled) {
        await base44.entities.Reminder.create({
          title: createdHabit.title,
          habit_id: createdHabit.id,
          time: variables.alarm.time,
          days: variables.alarm.days,
          alarm_level: variables.alarm.alarm_level,
          snooze_allowed: variables.alarm.snooze_allowed,
          max_snoozes: variables.alarm.max_snoozes,
          message: variables.alarm.message,
          is_active: true,
        });
        queryClient.invalidateQueries({ queryKey: ["reminders"] });
      }
      setShowForm(false);
    },
  });

  const updateHabit = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Habit.update(id, data),
    onSuccess: async (updatedHabit, { alarm, linkedReminderId }) => {
      queryClient.invalidateQueries({ queryKey: ["habits-all"] });
      queryClient.invalidateQueries({ queryKey: ["habits"] });
      const reminderData = alarm?.enabled
        ? {
            title: updatedHabit.title,
            habit_id: updatedHabit.id,
            time: alarm.time,
            days: alarm.days,
            alarm_level: alarm.alarm_level,
            snooze_allowed: alarm.snooze_allowed,
            max_snoozes: alarm.max_snoozes,
            message: alarm.message,
            is_active: true,
          }
        : null;
      if (reminderData) {
        if (linkedReminderId) {
          await base44.entities.Reminder.update(linkedReminderId, reminderData);
        } else {
          await base44.entities.Reminder.create(reminderData);
        }
      } else if (linkedReminderId) {
        await base44.entities.Reminder.delete(linkedReminderId);
      }
      queryClient.invalidateQueries({ queryKey: ["reminders"] });
      setEditingHabit(null);
      setShowForm(false);
    },
  });

  const deleteHabit = useMutation({
    mutationFn: (id) => base44.entities.Habit.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["habits-all"] });
      queryClient.invalidateQueries({ queryKey: ["habits"] });
    },
  });

  const handleSubmit = (data) => {
    const { alarm, ...habitData } = data;
    if (editingHabit) {
      const linkedReminder = reminders.find((r) => r.habit_id === editingHabit.id);
      updateHabit.mutate({ id: editingHabit.id, data: habitData, alarm, linkedReminderId: linkedReminder?.id });
    } else {
      createHabit.mutate({ ...habitData, alarm });
    }
  };

  const handleEdit = (habit) => {
    setEditingHabit(habit);
    setShowForm(true);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 md:py-10 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl md:text-3xl font-display font-bold text-foreground">My Habits ✨</h1>
        <Button
          onClick={() => { setEditingHabit(null); setShowForm(true); }}
          className="rounded-2xl font-body font-semibold"
        >
          <Plus className="w-4 h-4 mr-2" /> New Habit
        </Button>
      </div>

      <AnimatePresence>
        {showForm && (
          <HabitForm
            habit={editingHabit}
            linkedReminder={reminders.find((r) => r.habit_id === editingHabit?.id)}
            onSubmit={handleSubmit}
            onCancel={() => { setShowForm(false); setEditingHabit(null); }}
          />
        )}
      </AnimatePresence>

      {habits.length === 0 && !showForm ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-16 bg-card rounded-3xl border-2 border-dashed border-border"
        >
          <p className="text-5xl mb-4">🌱</p>
          <p className="font-display font-bold text-xl text-foreground mb-2">Build your first habit!</p>
          <p className="text-sm text-muted-foreground font-body mb-6 max-w-xs mx-auto">
            Start small — even 1 habit tracked daily can make a big difference.
          </p>
          <Button onClick={() => setShowForm(true)} className="rounded-2xl font-body font-semibold">
            <Plus className="w-4 h-4 mr-2" /> Create Habit
          </Button>
        </motion.div>
      ) : (
        <div className="space-y-3">
          {habits.map((habit, i) => (
            <motion.div
              key={habit.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="bg-card rounded-2xl border border-border p-4 flex items-center gap-4"
            >
              <div className="w-12 h-12 rounded-2xl bg-muted flex items-center justify-center text-2xl flex-shrink-0">
                {habit.emoji}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-display font-semibold text-foreground truncate">{habit.title}</p>
                <div className="flex items-center gap-3 mt-1">
                  <span className="text-xs text-muted-foreground font-body capitalize">{habit.category?.replace("_", " ")}</span>
                  <span className="text-xs text-muted-foreground font-body flex items-center gap-1">
                    <Flame className="w-3 h-3 text-accent" /> {habit.current_streak || 0}
                  </span>
                  <span className="text-xs text-primary font-body font-semibold">+{habit.points_per_completion} XP</span>
                </div>
              </div>
              <div className="flex gap-1">
                <Button variant="ghost" size="icon" className="rounded-xl" onClick={() => handleEdit(habit)}>
                  <Pencil className="w-4 h-4" />
                </Button>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="ghost" size="icon" className="rounded-xl text-destructive">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent className="rounded-3xl">
                    <AlertDialogHeader>
                      <AlertDialogTitle className="font-display">Delete "{habit.title}"?</AlertDialogTitle>
                      <AlertDialogDescription className="font-body">This will also delete all history for this habit. This can't be undone.</AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel className="rounded-xl font-body">Cancel</AlertDialogCancel>
                      <AlertDialogAction className="rounded-xl font-body bg-destructive" onClick={() => deleteHabit.mutate(habit.id)}>Delete</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}