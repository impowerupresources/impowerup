import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Trash2, LogOut, AlertTriangle, Sun, Moon, Monitor, Check, PanelBottom, PanelLeft, PanelTop } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { motion } from "framer-motion";
import { useTheme } from "@/lib/useTheme";
import { useAccentColor } from "@/lib/useAccentColor";
import { useNavPosition } from "@/lib/useNavPosition";
import { useAuth } from "@/lib/AuthContext";
import { toast } from "@/components/ui/use-toast";

const themeOptions = [
  { value: "light", label: "Light", icon: Sun },
  { value: "dark", label: "Dark", icon: Moon },
  { value: "system", label: "System", icon: Monitor },
];

export default function Settings() {
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const handleLogout = () => {
    base44.auth.logout("/login");
  };

  const handleDeleteAccount = async () => {
    if (!confirmDelete) {
      setConfirmDelete(true);
      return;
    }
    setDeleting(true);
    await base44.auth.updateMe({ deleted: true });
    base44.auth.logout("/login");
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 md:py-10 space-y-6">
      <motion.h1
        initial={{ opacity: 0, y: -16 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-2xl md:text-3xl font-display font-bold text-foreground"
      >
        Settings ⚙️
      </motion.h1>

      <ProfileSection />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.05 }}
        className="bg-card rounded-3xl border border-border p-5 space-y-3"
      >
        <h2 className="font-display font-bold text-base mb-1">Appearance</h2>
        <ThemeToggle />
        <NavPositionToggle />
        <AccentPicker />
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-card rounded-3xl border border-border p-5 space-y-3"
      >
        <h2 className="font-display font-bold text-base mb-1">Account</h2>
        <Button
          variant="outline"
          className="w-full rounded-2xl font-body font-semibold justify-start gap-3"
          onClick={handleLogout}
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </Button>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15 }}
        className="bg-destructive/5 rounded-3xl border border-destructive/20 p-5 space-y-3"
      >
        <h2 className="font-display font-bold text-base text-destructive flex items-center gap-2">
          <AlertTriangle className="w-4 h-4" /> Danger Zone
        </h2>

        {confirmDelete ? (
          <div className="space-y-3">
            <p className="text-sm font-body text-destructive">
              This will permanently delete your account and all your data. This cannot be undone.
            </p>
            <div className="flex gap-3">
              <Button
                variant="outline"
                className="flex-1 rounded-2xl font-body font-semibold"
                onClick={() => setConfirmDelete(false)}
              >
                Cancel
              </Button>
              <Button
                variant="destructive"
                className="flex-1 rounded-2xl font-body font-semibold"
                onClick={handleDeleteAccount}
                disabled={deleting}
              >
                {deleting ? "Deleting…" : "Yes, Delete"}
              </Button>
            </div>
          </div>
        ) : (
          <Button
            variant="destructive"
            className="w-full rounded-2xl font-body font-semibold justify-start gap-3"
            onClick={handleDeleteAccount}
          >
            <Trash2 className="w-4 h-4" />
            Delete Account
          </Button>
        )}
      </motion.div>
    </div>
  );
}

function ProfileSection() {
  const { user, checkUserAuth } = useAuth();
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [nickname, setNickname] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (user) {
      setFirstName(user.first_name || "");
      setLastName(user.last_name || "");
      setNickname(user.nickname || "");
    }
  }, [user]);

  const handleSave = async () => {
    setSaving(true);
    try {
      await base44.auth.updateMe({
        first_name: firstName.trim(),
        last_name: lastName.trim(),
        nickname: nickname.trim(),
      });
      await checkUserAuth();
      toast({ title: "Profile updated", description: "Your changes have been saved." });
    } catch (err) {
      toast({
        title: "Update failed",
        description: err.message || "Could not save your profile.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card rounded-3xl border border-border p-5 space-y-4"
    >
      <h2 className="font-display font-bold text-base mb-1">Profile</h2>
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-2">
          <Label htmlFor="firstName">First Name</Label>
          <Input
            id="firstName"
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
            className="rounded-xl"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="lastName">Last Name</Label>
          <Input
            id="lastName"
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
            className="rounded-xl"
          />
        </div>
      </div>
      <div className="space-y-2">
        <Label htmlFor="nickname">
          Nickname <span className="text-muted-foreground font-normal">(optional)</span>
        </Label>
        <Input
          id="nickname"
          placeholder="What should we call you?"
          value={nickname}
          onChange={(e) => setNickname(e.target.value)}
          className="rounded-xl"
        />
      </div>
      <Button
        onClick={handleSave}
        disabled={saving}
        className="w-full rounded-2xl font-body font-semibold"
      >
        {saving ? "Saving…" : "Save Profile"}
      </Button>
    </motion.div>
  );
}

function ThemeToggle() {
  const { theme, setTheme } = useTheme();

  return (
    <div className="grid grid-cols-3 gap-2">
      {themeOptions.map((opt) => {
        const Icon = opt.icon;
        const active = theme === opt.value;
        return (
          <button
            key={opt.value}
            onClick={() => setTheme(opt.value)}
            className={`flex flex-col items-center gap-2 py-4 rounded-2xl border-2 transition-all font-body font-semibold text-sm ${
              active
                ? "border-primary bg-primary/10 text-primary"
                : "border-border bg-transparent text-muted-foreground hover:bg-muted"
            }`}
          >
            <Icon className="w-5 h-5" />
            {opt.label}
          </button>
        );
      })}
    </div>
  );
}

function NavPositionToggle() {
  const { navPosition, setNavPosition } = useNavPosition();

  const options = [
    { value: "bottom", label: "Bottom", icon: PanelBottom },
    { value: "side", label: "Side", icon: PanelLeft },
    { value: "top", label: "Top", icon: PanelTop },
  ];

  return (
    <div>
      <p className="text-sm font-body font-semibold text-muted-foreground mb-2">Navigation Position</p>
      <div className="grid grid-cols-3 gap-2">
        {options.map((opt) => {
          const Icon = opt.icon;
          const active = navPosition === opt.value;
          return (
            <button
              key={opt.value}
              onClick={() => setNavPosition(opt.value)}
              className={`flex flex-col items-center gap-2 py-4 rounded-2xl border-2 transition-all font-body font-semibold text-sm ${
                active
                  ? "border-primary bg-primary/10 text-primary"
                  : "border-border bg-transparent text-muted-foreground hover:bg-muted"
              }`}
            >
              <Icon className="w-5 h-5" />
              {opt.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function AccentPicker() {
  const { accentId, setAccent, presets, isCustom, customColor, setCustomColor, currentHex } = useAccentColor();

  return (
    <div className="space-y-3">
      <div>
        <p className="text-sm font-body font-semibold text-muted-foreground mb-2">Presets</p>
        <div className="flex flex-wrap gap-2">
          {presets.map((preset) => {
            const active = !isCustom && accentId === preset.id;
            return (
              <button
                key={preset.id}
                onClick={() => setAccent(preset.id)}
                className={`relative w-10 h-10 rounded-full transition-all ${
                  active ? "ring-2 ring-offset-2 ring-offset-card scale-110" : "hover:scale-110"
                }`}
                style={{
                  backgroundColor: preset.swatch,
                  boxShadow: active ? `0 0 0 2px ${preset.swatch}` : undefined,
                }}
                title={preset.name}
              >
                {active && <Check className="absolute inset-0 m-auto w-5 h-5 text-white" />}
              </button>
            );
          })}
        </div>
      </div>

      <div className="pt-1">
        <p className="text-sm font-body font-semibold text-muted-foreground mb-2">
          Custom Hue
        </p>
        <div className="flex items-center gap-3">
          <label
            className="relative w-10 h-10 rounded-full cursor-pointer overflow-hidden border-2 border-border shrink-0"
            style={{
              backgroundColor: currentHex,
              boxShadow: isCustom ? `0 0 0 2px ${currentHex}` : undefined,
            }}
          >
            {isCustom && <Check className="absolute inset-0 m-auto w-5 h-5 text-white" />}
            <input
              type="color"
              value={isCustom ? customColor : currentHex}
              onChange={(e) => setCustomColor(e.target.value)}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
          </label>
          <input
            type="color"
            value={isCustom ? customColor : currentHex}
            onChange={(e) => setCustomColor(e.target.value)}
            className="flex-1 h-10 w-full rounded-xl border border-border bg-transparent cursor-pointer"
          />
          <span className="text-xs font-mono text-muted-foreground uppercase shrink-0">
            {currentHex}
          </span>
        </div>
        {isCustom && (
          <button
            onClick={() => setAccent("green")}
            className="mt-2 text-xs font-body font-semibold text-muted-foreground hover:text-foreground transition-colors"
          >
            Reset to preset
          </button>
        )}
      </div>
    </div>
  );
}